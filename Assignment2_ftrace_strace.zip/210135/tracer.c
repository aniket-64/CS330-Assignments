#include<context.h>
#include<memory.h>
#include<lib.h>
#include<entry.h>
#include<file.h>
#include<tracer.h>


///////////////////////////////////////////////////////////////////////////
//// 		Start of Trace buffer functionality 		      /////
///////////////////////////////////////////////////////////////////////////

int is_valid_mem_range(unsigned long buff, u32 count, int access_bit) 
{
	struct exec_context *pcb = get_current_ctx();
	if(pcb == NULL){
		return -EINVAL;
	}
	
	unsigned long buff_end = buff + count;

	if(pcb->mms[MM_SEG_CODE].start <= buff && buff_end <= pcb->mms[MM_SEG_CODE].next_free){
		// if((access_bit & 2) != 0){
		// 	// if trying to write, send badmem
		// 	return -EBADMEM;
		// }
		// printk("%d\n", pcb->mms[MM_SEG_CODE].access_flags);
		for(int i = 0; i<3; i++){
			// printk("%d ", (access_bit & (1<<i)));
			// printk("%d\n", (((pcb->mms[MM_SEG_CODE].access_flags & (1<<i)) == 0)));
			if(((access_bit & (1<<i)) != 0) && (((pcb->mms[MM_SEG_CODE].access_flags & (1<<i)) == 0))){
				// printk("hemlo\n");
				return -EBADMEM;
			}
		}
		return 0;
	}
	if(pcb->mms[MM_SEG_RODATA].start <= buff && buff_end <= pcb->mms[MM_SEG_RODATA].next_free){
		// if((access_bit & 2) != 0){
		// 	// if trying to write, send badmem
		// 	return -EBADMEM;
		// }
		for(int i = 0; i<3; i++){
			// printk("%d", 1<<i);
			if(((access_bit & (1<<i)) != 0) && (((pcb->mms[MM_SEG_RODATA].access_flags & (1<<i)) == 0))){
				return -EBADMEM;
			}
		}
		return 0;
	}
	if(pcb->mms[MM_SEG_DATA].start <= buff && buff_end <= pcb->mms[MM_SEG_DATA].next_free){
		for(int i = 0; i<3; i++){
			if(((access_bit & (1<<i)) != 0) && (((pcb->mms[MM_SEG_DATA].access_flags & (1<<i)) == 0))){
				return -EBADMEM;
			}
		}
		return 0;
	}
	if(pcb->mms[MM_SEG_STACK].start <= buff && buff_end <= pcb->mms[MM_SEG_STACK].end){
		for(int i = 0; i<3; i++){
			if(((access_bit & (1<<i)) != 0) && (((pcb->mms[MM_SEG_STACK].access_flags & (1<<i)) == 0))){
				return -EBADMEM;
			}
		}
		return 0;
	}

	// for(u32 reg = 0; reg<MAX_MM_SEGS; reg++){
	// 	// if(pcb->mms[i] != )
	// 	if(pcb->mms[reg].start <= buff && buff_end <= pcb->mms[reg].end){
	// 		for(int i = 0; i<3; i++){
	// 			if(((access_bit & (1<<i)) != 0) && (((pcb->mms[reg].access_flags & (1<<i)) == 0))){
	// 				return -EBADMEM;
	// 			}
	// 		}
	// 		return 0;
	// 	}
	// }

	// check on vm area
	struct vm_area *vm_ptr = pcb->vm_area;
	// printk("hello\n");
	// printk("requested address range: %lu to %lu, count: %u\n", buff, buff_end, count);
	// printk("%d\n", access_bit);
	struct vm_area *vm_start = pcb->vm_area;
	u32 first_flag = 1;
	while(vm_ptr != NULL){
		if(!first_flag){
			if(vm_ptr == vm_start){
				break;
			}
		}
		first_flag = 0;
		// printk("addrstart: %lu addrend: %lu", vm_ptr->vm_start, vm_ptr->vm_end);
		if(vm_ptr->vm_start <= buff && buff_end <= vm_ptr->vm_end){
			// printk("vm:%d\n", vm_ptr->access_flags);
			if((access_bit & 1) != 0 && (vm_ptr->access_flags & 1) == 0){
				return -EBADMEM;
			}
			if((access_bit & 2) != 0 && (vm_ptr->access_flags & 2) == 0){
				// printk("why not\n");
				return -EBADMEM;
			}
			if((access_bit & 4) != 0 && (vm_ptr->access_flags & 4) == 0){
				return -EBADMEM;
			}
			// printk("why this?\n");
			return 0;
		}
		vm_ptr = vm_ptr->vm_next;
	}

	return -EBADMEM;
}


long trace_buffer_close(struct file *filep)
{
	if(filep == NULL){
		return -EINVAL;
	}

	// struct exec_context *ctx = get_current_ctx();
	// if(ctx == NULL){
	// 	return -EINVAL;
	// }
	
	// u32 index = MAX_OPEN_FILES;
	// for(int i = 0; i<MAX_OPEN_FILES; i++){
	// 	if(ctx->files[i] == filep){
	// 		index = i;
	// 		break;
	// 	}
	// }
	// if(index == MAX_OPEN_FILES){
	// 	return -EINVAL;
	// }

	if(filep->trace_buffer == NULL || filep->type == TRACE_BUFFER){
		return -EINVAL;
	}
	if(filep->trace_buffer->buffer == NULL){
		return -EINVAL;
	}
	if(filep->fops == NULL){
		return -EINVAL;
	}


	filep->ref_count--;
	if(filep->ref_count == 0){
		os_page_free(USER_REG, filep->trace_buffer->buffer);
		os_free(filep->fops, sizeof(struct fileops));
		// os_page_free(USER_REG, filep->fops);
		os_free(filep->trace_buffer, sizeof(struct trace_buffer_info));
		// os_page_free(USER_REG, filep->trace_buffer);
		os_free(filep, sizeof(struct file));
		// os_page_free(USER_REG, filep);
	}
	// ctx->files[index] = NULL;

	return 0;	
}



int trace_buffer_read(struct file *filep, char *buff, u32 count)
{
	if(filep == NULL){
		return -EINVAL;
	}
	u32 read_bytes = 0;

	int retval_mem = is_valid_mem_range((unsigned long) buff, count, 2);
	if(retval_mem != 0){
		return retval_mem;
	}

	if((filep->mode & O_READ) == 0){
		return -EINVAL;
	}
	if(filep->trace_buffer == NULL || filep->type != TRACE_BUFFER){
		return -EINVAL;
	}
	if(filep->trace_buffer->len == 0){
		return 0;
	}
	else{
		while(filep->trace_buffer->len != 0 && read_bytes < count){
			buff[read_bytes] = filep->trace_buffer->buffer[filep->trace_buffer->read_offset];
			read_bytes++;
			filep->trace_buffer->read_offset++;
			filep->trace_buffer->read_offset %= TRACE_BUFFER_MAX_SIZE;
			filep->trace_buffer->len--;
		}
	}

	return read_bytes;
	// return 0;
}


int trace_buffer_write(struct file *filep, char *buff, u32 count)
{
	if(filep == NULL){
		return -EINVAL;
	}
	u32 written_bytes = 0;

	// if(is_valid_mem_range((unsigned long) buff, count, 1) != 0){
	// 	return -EBADMEM;
	// }
	int retval_mem = is_valid_mem_range((unsigned long) buff, count, 1);
	if(retval_mem != 0){
		return retval_mem;
	}

	// printk("%d %d\n", filep->mode, (filep->mode & O_WRITE));
	// no need to check - kernel doing that already
	if((filep->mode & O_WRITE) == 0){
		return -EINVAL;
	}
	if(filep->trace_buffer == NULL || filep->type != TRACE_BUFFER){
		return -EINVAL;
	}
	if(count == 0){
		return 0;
	}

	if(filep->trace_buffer->len == 0){
		filep->trace_buffer->buffer[filep->trace_buffer->write_offset] = buff[written_bytes];
		filep->trace_buffer->write_offset++;
		filep->trace_buffer->write_offset %= TRACE_BUFFER_MAX_SIZE;
		written_bytes++;
		filep->trace_buffer->len++;

		while(filep->trace_buffer->read_offset != filep->trace_buffer->write_offset && written_bytes < count){
			filep->trace_buffer->buffer[filep->trace_buffer->write_offset] = buff[written_bytes];
			filep->trace_buffer->write_offset++;
			filep->trace_buffer->write_offset %= TRACE_BUFFER_MAX_SIZE;
			written_bytes++;
			filep->trace_buffer->len++;
		}
	}
	else{
		while(filep->trace_buffer->read_offset != filep->trace_buffer->write_offset && written_bytes < count){
			filep->trace_buffer->buffer[filep->trace_buffer->write_offset] = buff[written_bytes];
			filep->trace_buffer->write_offset++;
			filep->trace_buffer->write_offset %= TRACE_BUFFER_MAX_SIZE;
			written_bytes++;
			filep->trace_buffer->len++;
		}
	}
	return written_bytes;
    // return 0;
}

int sys_create_trace_buffer(struct exec_context *current, int mode)
{
	// check for empty fd
	if(current != NULL){
		if(mode != O_RDWR && mode != O_READ && mode != O_WRITE){
			return -EINVAL;
		}
		int available_descriptor = 0;
		while(available_descriptor < MAX_OPEN_FILES){
			if(current->files[available_descriptor] != NULL){
				available_descriptor++;
			}
			else{
				break;
			}
		}
		if(available_descriptor == MAX_OPEN_FILES){
			// no desc available
			return -EINVAL;
		}
		else{
			// found fd
			// allocate struct file
			struct file *file_pointer = (struct file *) os_alloc(sizeof(struct file));
			// struct file *file_pointer = (struct file *) os_page_alloc(USER_REG);
			if(file_pointer == NULL){
				return -ENOMEM;
			}
			file_pointer->type = TRACE_BUFFER;
			file_pointer->inode = NULL;
			file_pointer->mode = mode;
			file_pointer->offp = 0;
			file_pointer->ref_count = 1;
			// alloc trace_buffer_info
			// file_pointer->trace_buffer = (struct trace_buffer_info *) os_page_alloc(USER_REG);
			file_pointer->trace_buffer = (struct trace_buffer_info *) os_alloc(sizeof(struct trace_buffer_info));
			if(file_pointer->trace_buffer == NULL){
				// avoid memleaks
				os_free(file_pointer, sizeof(struct file));
				// os_page_free(USER_REG, file_pointer);
				return -ENOMEM;
			}
			// allocate the actual buffer
			file_pointer->trace_buffer->buffer = (char *) os_page_alloc(USER_REG);
			if(file_pointer->trace_buffer->buffer == NULL){
				// avoid memleaks
				os_free(file_pointer->trace_buffer, sizeof(struct trace_buffer_info));
				// os_page_free(USER_REG, file_pointer->trace_buffer);
				os_free(file_pointer, sizeof(struct file));
				// os_page_free(USER_REG, file_pointer);
				return -ENOMEM;
			}
			file_pointer->trace_buffer->len = 0;
			file_pointer->trace_buffer->read_offset = 0;
			file_pointer->trace_buffer->write_offset = 0;
			// allocate fileops struct
			// file_pointer->fops = (struct fileops *) os_page_alloc(USER_REG);
			file_pointer->fops = (struct fileops *) os_alloc(sizeof(struct fileops));
			if(file_pointer->fops == NULL){
				os_page_free(USER_REG, file_pointer->trace_buffer->buffer);
				os_free(file_pointer->trace_buffer, sizeof(struct trace_buffer_info));
				// os_page_free(USER_REG, file_pointer->trace_buffer);
				os_free(file_pointer, sizeof(struct file));
				// os_page_free(USER_REG, file_pointer);
				return -ENOMEM;
			}
			file_pointer->fops->read = &trace_buffer_read;
			file_pointer->fops->write = &trace_buffer_write;
			file_pointer->fops->close = &trace_buffer_close;

			current->files[available_descriptor] = file_pointer;
			return available_descriptor;
		}
	}
	else{
		return -EINVAL;
	}
	// return 0;
}

///////////////////////////////////////////////////////////////////////////
//// 		Start of strace functionality 		      	      /////
///////////////////////////////////////////////////////////////////////////

int trace_write_helper(struct file *filep, char *buff, u32 count){
	if(filep == NULL || buff == NULL){
		return -EINVAL;
	}
	u32 written_bytes = 0;
	// printk("inside trace write helper\n");

	if((filep->mode & O_WRITE) == 0){
		// printk("inside trace write helper perm check fail\n");
		return -EINVAL;
	}
	if(count == 0){
		return 0;
	}

	if(filep->trace_buffer->len == 0){
		filep->trace_buffer->buffer[filep->trace_buffer->write_offset] = buff[written_bytes];
		filep->trace_buffer->write_offset++;
		filep->trace_buffer->write_offset %= TRACE_BUFFER_MAX_SIZE;
		written_bytes++;
		filep->trace_buffer->len++;

		while(filep->trace_buffer->read_offset != filep->trace_buffer->write_offset && written_bytes < count){
			filep->trace_buffer->buffer[filep->trace_buffer->write_offset] = buff[written_bytes];
			filep->trace_buffer->write_offset++;
			filep->trace_buffer->write_offset %= TRACE_BUFFER_MAX_SIZE;
			written_bytes++;
			filep->trace_buffer->len++;
		}
	}
	else{
		while(filep->trace_buffer->read_offset != filep->trace_buffer->write_offset && written_bytes < count){
			filep->trace_buffer->buffer[filep->trace_buffer->write_offset] = buff[written_bytes];
			filep->trace_buffer->write_offset++;
			filep->trace_buffer->write_offset %= TRACE_BUFFER_MAX_SIZE;
			written_bytes++;
			filep->trace_buffer->len++;
		}
	}
	return written_bytes;
}


int trace_read_helper(struct file *filep, char *buff, u64 count)
{
	if(filep == NULL){
		return -EINVAL;
	}
	u64 read_bytes = 0;

	if((filep->mode & O_READ) == 0){
		return -EINVAL;
	}

	if(filep->trace_buffer->len == 0){
		return 0;
	}
	else{
		while(filep->trace_buffer->len != 0 && read_bytes < count){
			buff[read_bytes] = filep->trace_buffer->buffer[filep->trace_buffer->read_offset];
			read_bytes++;
			filep->trace_buffer->read_offset++;
			filep->trace_buffer->read_offset %= TRACE_BUFFER_MAX_SIZE;
			filep->trace_buffer->len--;
		}
	}

	return read_bytes;
	// return 0;
}


int perform_tracing(u64 syscall_num, u64 param1, u64 param2, u64 param3, u64 param4)
{
	if(syscall_num == SYSCALL_EXIT){
		return 0;
	}
	struct exec_context *pcb = get_current_ctx();
	if(pcb == NULL){
		return -EINVAL;
	}
	if(pcb->st_md_base == NULL){
		// printk("why this bro, this is wrong\n");
		pcb->st_md_base = (struct strace_head *) os_alloc(sizeof(struct strace_head));
		// pcb->st_md_base = (struct strace_head *) os_page_alloc(USER_REG);
		if(pcb->st_md_base == NULL){
			return -EINVAL;
		}
		pcb->st_md_base->count = 0;
		pcb->st_md_base->is_traced = 0;
		pcb->st_md_base->next = NULL;
		pcb->st_md_base->last = NULL;
		// pcb->st_md_base->tracing_mode = 
	}
	if(pcb->st_md_base->is_traced == 0){
		return 0;
	}
	if(syscall_num == SYSCALL_END_STRACE){
		return 0;
	}
	// printk("doomed here\n");
	u32 num_args = 0;

	if(syscall_num == SYSCALL_GETPID
	|| syscall_num == SYSCALL_GETPPID
	|| syscall_num == SYSCALL_FORK
	|| syscall_num == SYSCALL_CFORK
	|| syscall_num == SYSCALL_VFORK
	|| syscall_num == SYSCALL_PHYS_INFO
	|| syscall_num == SYSCALL_END_STRACE
	|| syscall_num == SYSCALL_GET_COW_F
	|| syscall_num == SYSCALL_GET_USER_P
	|| syscall_num == SYSCALL_STATS
	){
		num_args = 0;
	}
	else if(syscall_num == SYSCALL_EXIT
	|| syscall_num == SYSCALL_CLOSE
	|| syscall_num == SYSCALL_TRACE_BUFFER
	|| syscall_num == SYSCALL_DUP
	|| syscall_num == SYSCALL_PMAP
	|| syscall_num == SYSCALL_SLEEP
	|| syscall_num == SYSCALL_DUMP_PTT
	|| syscall_num == SYSCALL_CONFIGURE
	// check alarm and shrink!
	|| syscall_num == SYSCALL_ALARM
	){
		num_args = 1;
	}
	else if(syscall_num == SYSCALL_SIGNAL
	|| syscall_num == SYSCALL_SHRINK
	|| syscall_num == SYSCALL_STRACE
	|| syscall_num == SYSCALL_START_STRACE
	|| syscall_num == SYSCALL_DUP2
	|| syscall_num == SYSCALL_OPEN	//open takes 2 args
	|| syscall_num == SYSCALL_MUNMAP
	|| syscall_num == SYSCALL_CLONE
	|| syscall_num == SYSCALL_EXPAND
	){
		num_args = 2;
	}
	else if(syscall_num == SYSCALL_MPROTECT
	|| syscall_num == SYSCALL_READ_STRACE
	|| syscall_num == SYSCALL_READ_FTRACE
	|| syscall_num == SYSCALL_LSEEK
	|| syscall_num == SYSCALL_WRITE
	|| syscall_num == SYSCALL_READ
	){
		num_args = 3;
	}	
	else if(syscall_num == SYSCALL_MMAP
	|| syscall_num == SYSCALL_FTRACE
	){
		num_args = 4;
	}
	else return -EINVAL;

	// printk("syscall_num ");
	// struct strace_info *curr_debug = pcb->st_md_base->next;
	// while(curr_debug != NULL){
	// 	printk("%d ", curr_debug->syscall_num);
	// 	// printk("\n");
	// 	// if(curr_debug->syscall_num == syscall_num){
	// 	// 	found = 1;
	// 	// 	break;
	// 	// }
	// 	curr_debug = curr_debug->next;
	// }
	// printk("\n");


	if(pcb->st_md_base->tracing_mode == FILTERED_TRACING){
		u32 found = 0;
		struct strace_info *curr = pcb->st_md_base->next;
		while(curr != NULL){
			// printk("%d ", curr->syscall_num);
			// printk("\n");
			if(curr->syscall_num == syscall_num){
				found = 1;
				break;
			}
			curr = curr->next;
		}
		if(!found){
			// printk("not found sycall: %d\n", syscall_num);
			return 0;
		}
	}

	u64 *os_buff = NULL;

	if(num_args == 0){
		os_buff = (u64 *) os_alloc(sizeof(u64));
		// os_buff = (u64 *) os_page_alloc(USER_REG);
	}
	else if(num_args == 1){
		os_buff = (u64 *) os_alloc(2*sizeof(u64));
		// os_buff = (u64 *) os_page_alloc(USER_REG);
	}
	else if(num_args == 2){
		os_buff = (u64 *) os_alloc(3*sizeof(u64));
		// os_buff = (u64 *) os_page_alloc(USER_REG);
	}
	else if(num_args == 3){
		os_buff = (u64 *) os_alloc(4*sizeof(u64));
		// os_buff = (u64 *) os_page_alloc(USER_REG);
	}
	else{
		os_buff = (u64 *) os_alloc(5*sizeof(u64));
		// os_buff = (u64 *) os_page_alloc(USER_REG);
	}

	if(os_buff == NULL){
		return -EINVAL;
	}

	u32 write_fd = pcb->st_md_base->strace_fd;
	struct file *write_fp = pcb->files[write_fd];
	int ret = 0;

	// printk("%d ", syscall_num);
	if(num_args == 0){
		os_buff[0] = syscall_num;
		ret = trace_write_helper(write_fp, (char *)os_buff, sizeof(u64));
		os_free(os_buff, sizeof(u64));
		// os_page_free(USER_REG, os_buff);
		if(ret != sizeof(u64)){
	// printk("doomed num0\n");
			return -EINVAL;
		}
	}
	else if(num_args == 1){
		os_buff[0] = syscall_num;
		os_buff[1] = param1;
		ret = trace_write_helper(write_fp, (char *)os_buff, 2*sizeof(u64));
		os_free(os_buff, 2*sizeof(u64));
		// os_page_free(USER_REG, os_buff);
		if(ret != 2*sizeof(u64)){
	// printk("doomed num1\n");
			return -EINVAL;
		}
	}
	else if(num_args == 2){
		// printk("reached here\n");
		os_buff[0] = syscall_num;
		os_buff[1] = param1;
		os_buff[2] = param2;
		ret = trace_write_helper(write_fp, (char *)os_buff, 3*sizeof(u64));
		os_free(os_buff, 3*sizeof(u64));
		// os_page_free(USER_REG, os_buff);
		if(ret != 3*sizeof(u64)){

	// printk("doomed num2\n");
			return -EINVAL;
		}
	}
	else if(num_args == 3){
		os_buff[0] = syscall_num;
		os_buff[1] = param1;
		os_buff[2] = param2;
		os_buff[3] = param3;
		ret = trace_write_helper(write_fp, (char *)os_buff, 4*sizeof(u64));
		os_free(os_buff, 4*sizeof(u64));
		// os_page_free(USER_REG, os_buff);
		if(ret != 4*sizeof(u64)){
	// printk("doomed num3\n");
	// printk("%d", ret);
			return -EINVAL;
		}
	}
	else{
		os_buff[0] = syscall_num;
		os_buff[1] = param1;
		os_buff[2] = param2;
		os_buff[3] = param3;
		os_buff[4] = param4;
		ret = trace_write_helper(write_fp, (char *)os_buff, 5*sizeof(u64));
		os_free(os_buff, 5*sizeof(u64));
		// os_page_free(USER_REG, os_buff);
		if(ret != 5*sizeof(u64)){
	// printk("doomed num4\n");
			return -EINVAL;
		}
	}
    return 0;
}


int sys_strace(struct exec_context *current, int syscall_num, int action)
{
	if(current == NULL){
		return -EINVAL;
	}
	// if(current->st_md_base->tracing_mode == FULL_TRACING){
	// 	return 0;
	// }
	if(current->st_md_base == NULL){
		// printk("why this bro, this is wrong\n");
		current->st_md_base = (struct strace_head *) os_alloc(sizeof(struct strace_head));
		// pcb->st_md_base = (struct strace_head *) os_page_alloc(USER_REG);
		if(current->st_md_base == NULL){
			return -EINVAL;
		}
		current->st_md_base->count = 0;
		current->st_md_base->is_traced = 0;
		current->st_md_base->next = NULL;
		current->st_md_base->last = NULL;
		// pcb->st_md_base->tracing_mode = 
	}

	struct strace_info *curr = current->st_md_base->next;
	struct strace_info *prev = NULL;

	u32 found = 0;
	while(curr != NULL){
		if(curr->syscall_num == syscall_num){
			found = 1;
			break;
		}
		prev = curr;
		curr = curr->next;
	}
	
	if(action == ADD_STRACE){
		if(found != 0){
			return -EINVAL;
		}

		if(current->st_md_base->count == MAX_STRACE){
			return -EINVAL;
		}

		current->st_md_base->count++;
		struct strace_info *newnode = (struct strace_info *) os_alloc(sizeof(struct strace_info));
		// struct strace_info *newnode = (struct strace_info *) os_page_alloc(USER_REG);
		if(newnode == NULL){
			return -EINVAL;
		}
		if(current->st_md_base->next == NULL){
			current->st_md_base->next = newnode;
			current->st_md_base->last = newnode;
		}
		else{
			current->st_md_base->last->next = newnode;
			current->st_md_base->last = current->st_md_base->last->next;
		}
		if(current->st_md_base->last == NULL){
			return -EINVAL;
		}
		current->st_md_base->last->next = NULL;
		current->st_md_base->last->syscall_num = syscall_num;
		// printk("successfully added %d\n", syscall_num);

		// struct strace_info *curr = current->st_md_base->next;
		// while(curr != NULL){
		// 	printk("%d ", curr->syscall_num);
		// 	curr = curr->next;
		// }
		// printk("\n");

		return 0;
	}
	else if(action == REMOVE_STRACE){
		if(found == 0){
			return -EINVAL;
		}

		current->st_md_base->count--;
		if(prev == NULL){
			current->st_md_base->next = curr->next;
			if(current->st_md_base->last == curr){
				current->st_md_base->last = prev;
			}
		}
		else{
			prev->next = curr->next;
			if(current->st_md_base->last == curr){
				current->st_md_base->last = prev;
			}
		}
		os_free(curr, sizeof(struct strace_info));
		// os_page_free(USER_REG, curr);
		return 0;
	}
	else{
		return -EINVAL;
	}
	// struct strace_info *next = current->st_md_base->next;
	
	return -EINVAL;
	// return 0;
}

int sys_read_strace(struct file *filep, char *buff, u64 count)
{
	// printk("reached reasdstrace\n");
	if(filep == NULL || buff == NULL){
		return -EINVAL;
	}
	if(filep->type != TRACE_BUFFER || filep->trace_buffer == NULL){
		return -EINVAL;
	}
	// if(is_valid_mem_range(buff) != 0){
	// 	return -EINVAL;
	// }
	if(count == 0){
		return 0;
	}

	char *start = buff;
	int retval = 0;
	for(u64 i = 0; i<count; i++){
		// printk("@iter before %d tb_len %d rd_offset %d wr_offset %d\n", i+1, filep->trace_buffer->len, 
		// filep->trace_buffer->read_offset,
		// filep->trace_buffer->write_offset
		// );

		int ret = trace_read_helper(filep, start, 8);
		if(ret < 0){
			return -EINVAL;
		}
		else if(ret != 8){
			retval += ret;
			return retval;
		}
		
		retval += ret;

		// printk("@iter after %d tb_len %d rd_offset %d wr_offset %d\n", i+1, filep->trace_buffer->len, 
		// filep->trace_buffer->read_offset,
		// filep->trace_buffer->write_offset
		// );

		u64 syscall_num = *((u64 *)(start));

		u32 num_args = 0;

		if(syscall_num == SYSCALL_GETPID
		|| syscall_num == SYSCALL_GETPPID
		|| syscall_num == SYSCALL_FORK
		|| syscall_num == SYSCALL_CFORK
		|| syscall_num == SYSCALL_VFORK
		|| syscall_num == SYSCALL_PHYS_INFO
		|| syscall_num == SYSCALL_END_STRACE
		|| syscall_num == SYSCALL_GET_COW_F
		|| syscall_num == SYSCALL_GET_USER_P
		|| syscall_num == SYSCALL_STATS
		){
			num_args = 0;
		}
		else if(syscall_num == SYSCALL_EXIT
		|| syscall_num == SYSCALL_CLOSE
		|| syscall_num == SYSCALL_TRACE_BUFFER
		|| syscall_num == SYSCALL_DUP
		|| syscall_num == SYSCALL_PMAP
		|| syscall_num == SYSCALL_SLEEP
		|| syscall_num == SYSCALL_DUMP_PTT
		|| syscall_num == SYSCALL_CONFIGURE
		// check alarm and shrink!
		|| syscall_num == SYSCALL_ALARM
		){
			num_args = 1;
		}
		else if(syscall_num == SYSCALL_SIGNAL
		|| syscall_num == SYSCALL_SHRINK
		|| syscall_num == SYSCALL_STRACE
		|| syscall_num == SYSCALL_START_STRACE
		|| syscall_num == SYSCALL_DUP2
		|| syscall_num == SYSCALL_OPEN	//open takes 2 args
		|| syscall_num == SYSCALL_MUNMAP
		|| syscall_num == SYSCALL_CLONE
		|| syscall_num == SYSCALL_EXPAND
		){
			num_args = 2;
		}
		else if(syscall_num == SYSCALL_MPROTECT
		|| syscall_num == SYSCALL_READ_STRACE
		|| syscall_num == SYSCALL_READ_FTRACE
		|| syscall_num == SYSCALL_LSEEK
		|| syscall_num == SYSCALL_WRITE
		|| syscall_num == SYSCALL_READ
		){
			num_args = 3;
		}	
		else if(syscall_num == SYSCALL_MMAP
		|| syscall_num == SYSCALL_FTRACE
		){
			num_args = 4;
		}
		else return -EINVAL;

		start = (char *) (((u64 *) start) + 1);
		ret = trace_read_helper(filep, start, sizeof(u64)*num_args);
		if(ret != sizeof(u64)*num_args){
			return -EINVAL;
		}
		retval += ret;
		start = (char *) (((u64 *) start) + num_args);
	}
	return retval;
}

int sys_start_strace(struct exec_context *current, int fd, int tracing_mode)
{
	if(current == NULL){
		return -EINVAL;
	}

	if(tracing_mode != FULL_TRACING && tracing_mode != FILTERED_TRACING){
		return -EINVAL;
	}
	if(current->files[fd] == NULL || current->files[fd]->trace_buffer == NULL || current->files[fd]->type != TRACE_BUFFER){
		return -EINVAL;
	}

	if(current->st_md_base == NULL){
		current->st_md_base = os_alloc(sizeof(struct strace_head));
		// current->st_md_base = os_page_alloc(USER_REG);
		if(current->st_md_base == NULL){
			return -EINVAL;
		}
	}
	current->st_md_base->is_traced = 1;
	current->st_md_base->tracing_mode = tracing_mode;
	current->st_md_base->strace_fd = fd;
	// printk("hello\n");
	return 0;
}

int sys_end_strace(struct exec_context *current)
{
	if(current == NULL){
		return -EINVAL;
	}
	if(current->st_md_base == NULL){
		return -EINVAL;
	}
	current->st_md_base->is_traced = 0;
	struct strace_info *curr = current->st_md_base->next;
	struct strace_info *next = current->st_md_base->next;
	while(curr != NULL){
		next = curr->next;
		os_free(curr, sizeof(struct strace_info));
		// os_page_free(USER_REG, curr);
		curr = next;
	}

	current->st_md_base->next = NULL;
	current->st_md_base->last = NULL;
	current->st_md_base->count = 0;
	os_free(current->st_md_base, sizeof(struct strace_head));
	// os_page_free(USER_REG, current->st_md_base);
	current->st_md_base = NULL;
	return 0;
}



///////////////////////////////////////////////////////////////////////////
//// 		Start of ftrace functionality 		      	      /////
///////////////////////////////////////////////////////////////////////////

// long disable_ftrace_helper(){
// 	return 0;
// }

long do_ftrace(struct exec_context *ctx, unsigned long faddr, long action, long nargs, int fd_trace_buffer)
{
	// printk("i am here\n");
	// if(ctx->ft_md_base == NULL) ctx->ft_md_base = os_alloc(sizeof(struct ftrace_head));
	// if(ctx->ft_md_base->next == NULL){
	// 	ctx->ft_md_base->next = os_alloc(sizeof(struct ftrace_info));
	// }
	// ctx->ft_md_base->next->code_backup[0] = *(((u8 *) faddr)+1);
	// ctx->ft_md_base->next->next = NULL;
	// *((u8 *) faddr) = INV_OPCODE;
	// *(((u8 *) faddr)+1) = INV_OPCODE; 
	// *(((u8 *)faddr) + 2) = INV_OPCODE;
	// *(((u8 *)faddr) + 3) = INV_OPCODE;
	// // printk("%d\n", (int) (*((u8 *)(faddr))));
	// // if(*(((u8 *) faddr) + 1) == PUSH_RBP_OPCODE){
	// // 	printk("hemlo hello push rbp\n");
	// // }
	// // else if(*(((u8 *) faddr) + 1) == INV_OPCODE){
	// // 	printk("hello inv op\n");
	// // }

	if(ctx->ft_md_base == NULL){
		ctx->ft_md_base = (struct ftrace_head *) os_alloc(sizeof(struct ftrace_head));
		// ctx->ft_md_base = (struct ftrace_head *) os_page_alloc(USER_REG);
		if(ctx->ft_md_base == NULL){
			// printk("errmem\n");
			return -EINVAL;
		}
		ctx->ft_md_base->count = 0;
		ctx->ft_md_base->next = NULL;
		ctx->ft_md_base->last = NULL;
	}

	struct ftrace_info *prev = NULL;
	struct ftrace_info *curr = ctx->ft_md_base->next;
	while(curr != NULL){
		// printk("%x\n", curr->faddr);
		if(curr->faddr == faddr){
			// printk("found\n");
			break;
		}
		prev = curr;
		curr = curr->next;
	}
	// printk("action : %d", action);
	switch(action){
	case ADD_FTRACE:{
		if(curr != NULL){
			return -EINVAL;
		}

		if(ctx->ft_md_base->count == FTRACE_MAX){
			return -EINVAL;
		}

		if(ctx->files[fd_trace_buffer] == NULL){
			return -EINVAL;
		}
		if(ctx->files[fd_trace_buffer]->trace_buffer == NULL || ctx->files[fd_trace_buffer]->type != TRACE_BUFFER){
			return -EINVAL;
		}

		struct ftrace_info *newnode = (struct ftrace_info *) os_alloc(sizeof(struct ftrace_info));
		// struct ftrace_info *newnode = (struct ftrace_info *) os_page_alloc(USER_REG);
		if(newnode == NULL){
			// printk("memerr\n");
			return -EINVAL;
		}
		newnode->faddr = faddr;
		newnode->capture_backtrace = 0;
		newnode->next = NULL;
		newnode->fd = fd_trace_buffer;
		if(nargs > MAX_ARGS){
			os_free(newnode, sizeof(struct ftrace_info));
			// os_page_free(USER_REG, newnode);
			return -EINVAL;
		}
		newnode->num_args = nargs;
		newnode->code_backup[0] = *((u8*)faddr);
		newnode->code_backup[1] = *(((u8*)faddr) + 1);
		newnode->code_backup[2] = *(((u8*)faddr) + 2);
		newnode->code_backup[3] = *(((u8*)faddr) + 3);

		ctx->ft_md_base->count++;
		if(ctx->ft_md_base->last != NULL){
			ctx->ft_md_base->last->next = newnode;
			ctx->ft_md_base->last = newnode;
		}
		else{
			ctx->ft_md_base->next = newnode;
			ctx->ft_md_base->last = newnode;
		}

		return 0;
		break;
	}
	case ENABLE_FTRACE:{
		if(curr == NULL){
			// struct ftrace_info *curr2 = ctx->ft_md_base->next;
			// printk("%x needed\n", faddr);
			// while(curr2 != NULL){
			// 	printk("%x\n", curr2->faddr);
			// 	curr2 = curr2->next;
			// }

			return -EINVAL;
		}
		// if(*((u8 *) faddr) == INV_OPCODE){
		// 	return -EINVAL;
		// }
		*((u8*)faddr) = INV_OPCODE;
		*(((u8*)faddr) + 1) = INV_OPCODE;
		*(((u8*)faddr) + 2) = INV_OPCODE;
		*(((u8*)faddr) + 3) = INV_OPCODE;
		return 0;
		break;
	}
	case ENABLE_BACKTRACE:{
		if(curr == NULL){
			return -EINVAL;
		}
		// if(*((u8 *) faddr) == INV_OPCODE && curr->capture_backtrace == 1){
		// 	return -EINVAL;
		// }
		curr->capture_backtrace = 1;
		*((u8*)faddr) = INV_OPCODE;
		*(((u8*)faddr) + 1) = INV_OPCODE;
		*(((u8*)faddr) + 2) = INV_OPCODE;
		*(((u8*)faddr) + 3) = INV_OPCODE;
		return 0;
		break;
	}
	case REMOVE_FTRACE:{
		if(curr == NULL){
			return -EINVAL;
		}

		*((u8*)faddr) = curr->code_backup[0];
		*(((u8*)faddr) + 1) = curr->code_backup[1];
		*(((u8*)faddr) + 2) = curr->code_backup[2];
		*(((u8*)faddr) + 3) = curr->code_backup[3];

		if(curr->capture_backtrace == 1){
			curr->capture_backtrace = 0;
		}
		
		if(prev == NULL){
			ctx->ft_md_base->next = curr->next;
		}
		else{
			prev->next = curr->next;
		}
		if(curr == ctx->ft_md_base->last){
			ctx->ft_md_base->last = prev;
		}

		os_free(curr, sizeof(struct ftrace_info));
		// os_page_free(USER_REG, curr);
		ctx->ft_md_base->count--;
		return 0;
		break;
	}
	case DISABLE_FTRACE:{
		if(curr == NULL){
			return -EINVAL;
		}
		// if(*((u8 *) faddr) == PUSH_RBP_OPCODE){
		// 	return -EINVAL;
		// }
		curr->capture_backtrace = 0;
		// to do this or not?
		*((u8*)faddr) = curr->code_backup[0];
		*(((u8*)faddr) + 1) = curr->code_backup[1];
		*(((u8*)faddr) + 2) = curr->code_backup[2];
		*(((u8*)faddr) + 3) = curr->code_backup[3];
		return 0;
		break;
	}
	case DISABLE_BACKTRACE:{
		if(curr == NULL){
			return -EINVAL;
		}
		// if(*((u8 *) faddr) == PUSH_RBP_OPCODE){
		// 	return -EINVAL;
		// }
		curr->capture_backtrace = 0;
		*((u8*)faddr) = curr->code_backup[0];
		*(((u8*)faddr) + 1) = curr->code_backup[1];
		*(((u8*)faddr) + 2) = curr->code_backup[2];
		*(((u8*)faddr) + 3) = curr->code_backup[3];
		return 0;
		break;
	}
	default:
		return -EINVAL;
	}

    return -EINVAL;
}

//Fault handler
long handle_ftrace_fault(struct user_regs *regs)
{
	// printk("i got invoked\n");
	struct exec_context *ctx = get_current_ctx();
	if(ctx == NULL){
		// printk("ctx failed\n");
		return -EINVAL;
	}
	u64 func_addr = regs->entry_rip;
	// printk("rip before %x\n", regs->entry_rip);
	regs->entry_rip = regs->entry_rip + 4;
	// printk("rip ptr %x rip in pcb %x\n", regs->entry_rip, ctx->regs.entry_rip);
	// ctx->regs.entry_rip = regs->entry_rip;
	// printk("rip after %x\n", regs->entry_rip);

	// printk("rsp before %x\n", regs->entry_rsp);
	regs->entry_rsp = regs->entry_rsp - 8;
	// printk("rsp ptr %x rsp in pcb %x\n", regs->entry_rsp, ctx->regs.entry_rsp);
	// ctx->regs.entry_rsp = regs->entry_rsp;
	// printk("rsp after %x\n", regs->entry_rsp);

	// printk("rbp before %x\n", regs->rbp);
	*((u64 *) (regs->entry_rsp)) = regs->rbp;
	regs->rbp = regs->entry_rsp;
	// printk("rbp ptr %x rbp in pcb %x\n", regs->rbp, ctx->regs.rbp);
	// ctx->regs.rbp = regs->rbp;
	// printk("rbp after %x\n", regs->rbp);

	// rdi, rsi, rdx, rcx, r8
	if(ctx->ft_md_base == NULL){
		// printk("ftmdbase null!\n");
		return -EINVAL;
	}
	u32 found = 0;
	struct ftrace_info *curr = ctx->ft_md_base->next;
	while(curr != NULL){
		if(curr->faddr == func_addr){
			found = 1;
			break;
		}
		curr = curr->next;
	}

	if(!found || curr == NULL){
		// printk("not found %d\n", found);
		return -EINVAL;
	}

	u64 writtenbytes = 0;
	// printk("reached os_buff alloc stage\n");
	u64 *os_buff = (u64 *) os_alloc((1 + curr->num_args)*sizeof(u64));
	// u64 *os_buff = (u64 *) os_page_alloc(USER_REG);
	os_buff[0] = func_addr;
	for(int i = 0; i<curr->num_args; i++){
		if(i == 0){
			os_buff[i+1] = regs->rdi;
		}
		if(i == 1){
			os_buff[i+1] = regs->rsi;
		}
		if(i == 2){
			os_buff[i+1] = regs->rdx;
		}
		if(i == 3){
			os_buff[i+1] = regs->rcx;
		}
		if(i == 4){
			os_buff[i+1] = regs->r8;
		}
	}
	int ret = trace_write_helper(ctx->files[curr->fd], (char *) os_buff, (1+curr->num_args)*sizeof(u64));
	if(ret < 0){
		return ret;
	}
	else if(ret != (1+curr->num_args)*sizeof(u64)){
		return -EINVAL;
	}
	writtenbytes += ret;

	os_free(os_buff, sizeof((1 + curr->num_args)*sizeof(u64)));

	if(curr->capture_backtrace == 1){

		u64 *backtrace_buff = (u64 *) os_page_alloc(USER_REG);
		u64 count_bt = 1;


		u64 stack_address = regs->rbp;
		u64 backtrace_address = *(((u64 *) (stack_address)) + 1);

		u32 break_flag = 0;
		// u32 cnt = 0;
		while(!break_flag){
			// printk("wrote %x iter %d\n", backtrace_address, cnt);
			// ret = trace_write_helper(ctx->files[curr->fd], (char *) &backtrace_address, sizeof(u64));
			// if(ret < 0){
			// 	return ret;
			// }
			// else if(ret != sizeof(u64)){
			// 	return -EINVAL;
			// }
			backtrace_buff[count_bt - 1] = backtrace_address;
			count_bt++;

			stack_address = *((u64 *) (stack_address));
			backtrace_address = *(((u64 *) (stack_address)) + 1);
			if(backtrace_address == END_ADDR){
				break_flag = 1;
				// printk("wrote %x iter %d\n", backtrace_address, cnt);
				// trace_write_helper(ctx->files[curr->fd], (char *) &backtrace_address, sizeof(u64));
				// backtrace_buff[count_bt - 1] = backtrace_address;
			}
			// cnt++;
		}

		ret = trace_write_helper(ctx->files[curr->fd], (char *) &count_bt, sizeof(u64));
		if(ret < 0){
			return ret;
		}
		else if(ret != sizeof(u64)){
			return -EINVAL;
		}
		writtenbytes += ret;

		ret = trace_write_helper(ctx->files[curr->fd], (char *) &func_addr, sizeof(u64));
		if(ret < 0){
			return ret;
		}
		else if(ret != sizeof(u64)){
			return -EINVAL;
		}
		writtenbytes += ret;

		ret = trace_write_helper(ctx->files[curr->fd], (char *) backtrace_buff, (count_bt-1)*sizeof(u64));
		if(ret < 0){
			return ret;
		}
		else if(ret != (count_bt-1)*sizeof(u64)){
			return -EINVAL;
		}
		writtenbytes += ret;

		os_page_free(USER_REG, backtrace_buff);
	}
	// printk("wrote %d\n\n", writtenbytes);
    return 0;
}


int sys_read_ftrace(struct file *filep, char *buff, u64 count)
{
	if(filep == NULL || buff == NULL){
		return -EINVAL;
	}
	// if(is_valid_mem_range(buff) != 0){
	// 	return -EINVAL;
	// }
	if(filep->type != TRACE_BUFFER || filep->trace_buffer == NULL){
		return -EINVAL;
	}

	if(count == 0){
		return 0;
	}

	char *start = buff;
	int retval = 0;
	for(u64 i = 0; i<count; i++){
		int ret = trace_read_helper(filep, start, sizeof(u64));
		if(ret < 0){
			return -EINVAL;
		}
		else if(ret != 8){
			retval += ret;
			return retval;
		}
		
		retval += ret;
		u64 func_addr = *((u64 *)(start));

		u32 num_args = 0;

		struct exec_context *ctx = get_current_ctx();
		if(ctx == NULL){
			return -EINVAL;
		}
		if(ctx->ft_md_base == NULL){
			return -EINVAL;
		}
		struct ftrace_info *curr = ctx->ft_md_base->next;
		u32 found = 0;
		while(curr != NULL){
			if(func_addr == curr->faddr){
				found = 1;
				break;
			}
			curr = curr->next;
		}
		if(!found || curr == NULL){
			return -EINVAL;
		}

		num_args = curr->num_args;

		start = (char *) (((u64 *) start) + 1);
		ret = trace_read_helper(filep, start, sizeof(u64)*num_args);
		if(ret != sizeof(u64)*num_args){
			return -EINVAL;
		}
		retval += ret;
		start = (char *) (((u64 *) start) + num_args);

		if(curr->capture_backtrace == 1){
			// u32 break_flag = 0;
			u64 count_bt = 0; // buffer to copy from trace buffer to os space, will then write to user buffer
			ret = trace_read_helper(filep, (char *) &count_bt, sizeof(u64));
			if(ret < 0){
				return -EINVAL;
			}
			else if(ret != sizeof(u64)){
				// retval += ret;
				return retval;
			}

			// while(!break_flag){
			for(int ind = 0; ind < count_bt; ind++){
				u64 temp_copy_buffer;
				ret = trace_read_helper(filep, (char *) &temp_copy_buffer, sizeof(u64));
				if(ret < 0){
					return -EINVAL;
				}
				else if(ret != sizeof(u64)){
					retval += ret;
					return retval;
				}
				// u64 is_end_addr = *((u64 *) start);
				// if(temp_copy_buffer != END_ADDR){
				*((u64 *) start) = temp_copy_buffer;
				start = (char *) (((u64 *) start) + 1);
				retval += ret;
				// }
				// else break_flag = 1;
				// if(is_end_addr == )
			}
		}
	}
	// printk("returning from here %d\n", retval);
	return retval;

    return 0;
}
