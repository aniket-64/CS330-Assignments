#include <stdio.h>
#include<sys/mman.h>

void *free_list = NULL;

#define CHUNK_SIZE ((unsigned long)4194304)
// 4MB

unsigned long find_request_size(unsigned long size){
	// function to return minimum size required to be requested from OS
	// returns nearest higher multiple of 4MB
	unsigned long req = size;
	if(size%CHUNK_SIZE != 0){
		req = size + CHUNK_SIZE - size%CHUNK_SIZE;
	}
	return req;
}

void *memalloc(unsigned long size) 
{
	if(size == 0){
		return NULL;
	}

	if(size%8 != 0){
		// align to 8byte boundary
		size = size + 8 - size%8;
	}
	if(size < 16){
		// minimum (size+8) of request must be 24 bytes, so size >= 16
		size = 16;
	}

	// printf("memalloc() called\n");
	int flag = 0;
	void *return_address = NULL;
	void *prev_block = NULL;
	void *next_block = NULL;
	void *curr_block = free_list;

	
	while(!flag || curr_block != NULL){

		if(!flag && curr_block == NULL){
			// we have reached end of the free list and still not allocated. 
			// so we invoke mmap
			unsigned long req_size = find_request_size(size + 8);
			void *new_allocation = mmap(NULL, req_size, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);

			if(new_allocation == ((void *) -1)){
				// mmap failed
				return NULL;
			}
	
			if(prev_block == NULL){
				// free list empty, handle accordingly
				free_list = new_allocation;
				curr_block = new_allocation;

				*((unsigned long int *) curr_block) = req_size;

				*((void **) ((long *)curr_block + 1)) = NULL;
				*((void **) ((long *)curr_block + 2)) = NULL;
			}
			else{
				// insert new memory chunk at the end of freelist
				curr_block = new_allocation;

				*((unsigned long int *) curr_block) = req_size;

				*((void **) ((long *)curr_block + 1)) = NULL;
				*((void **) ((long *)curr_block + 2)) = prev_block;

				*((void **) ((long *)prev_block + 1)) = curr_block;
			}
		}

		unsigned long size_block = *((unsigned long *) curr_block);
		next_block = *((void **) ((long *)curr_block + 1));
		prev_block = *((void **) ((long *)curr_block + 2));
		
		if(size_block < size + 8){
			// current block not enough, move to next in list
			prev_block = curr_block;
			curr_block = next_block;
		}
		else if(size_block >= size + 8 && size_block < size + 32){
			// less than 24 bytes remaining, so attach them as padding
			flag = 1;
			return_address = (void *)((long *)curr_block + 1);

			// handle various cases depending on location of current block in freelist
			// delete the entire current block
			if(prev_block != NULL && next_block != NULL){
				*((void **) ((long *)prev_block + 1)) = next_block;
				*((void **) ((long *)next_block + 2)) = prev_block;
			}
			else if(prev_block == NULL && next_block != NULL){
				free_list = next_block;
				*((void **) ((long *)next_block + 2)) = NULL;
			}
			else if(next_block == NULL && prev_block != NULL){
				*((void **) ((long *)prev_block + 1)) = NULL;
			}
			else{
				free_list = NULL;
			}

			break;
		}
		else{
			// sufficient size of block is there to create a new block
			flag = 1;
			unsigned long offset = size + 8;
			unsigned long old_size = *((unsigned long int *) curr_block);

			return_address = (void *)((long *)curr_block + 1);
			*((unsigned long int *) curr_block) = offset;

			void *new_block_start = curr_block + offset;
			*((unsigned long *) new_block_start) = old_size - offset;

			if(prev_block != NULL && next_block != NULL){
				// delete current block
				*((void **) ((long *)prev_block + 1)) = next_block;
				*((void **) ((long *)next_block + 2)) = prev_block;

				// insert new node at the front of the list
				void *old_start = free_list;
				free_list = new_block_start;
				*((void **) ((long *)new_block_start + 1)) = old_start;
				*((void **) ((long *)new_block_start + 2)) = NULL;
				
				if(old_start != NULL){
					*((void **) ((long *)old_start + 2)) = new_block_start;
				}
			}
			else if(prev_block == NULL && next_block != NULL){
				free_list = new_block_start;
				*((void **) ((long *)new_block_start + 2)) = NULL;
				*((void **) ((long *)new_block_start + 1)) = next_block;
				*((void **) ((long *)next_block + 2)) = new_block_start;
			}
			else if(next_block == NULL && prev_block != NULL){
				*((void **) ((long *)prev_block + 1)) = next_block;

				void *old_start = free_list;
				free_list = new_block_start;
				*((void **) ((long *)new_block_start + 1)) = old_start;
				*((void **) ((long *)new_block_start + 2)) = NULL;
				
				if(old_start != NULL){
					*((void **) ((long *)old_start + 2)) = new_block_start;
				}
			}
			else{
				free_list = new_block_start;
				*((void **) ((long *)new_block_start + 1)) = NULL;
				*((void **) ((long *)new_block_start + 2)) = NULL;
			}

			break;
		}
	}

	return return_address;
}

int memfree(void *ptr)
{
	// printf("memfree() called\n");
	if(ptr == NULL){
		return -1;
	}

	void *prev_block = NULL;
	void *next_block = NULL;
	void *curr_block = free_list;	

	void *contig_free_left = NULL;
	void *contig_free_right = NULL;

	unsigned long int to_free_size = *((unsigned long *) (ptr - 8));

	if(to_free_size < 24) return -1;
	// invalid block to free

	void *to_free_address = (void *)((long *)ptr - 1);

	while(curr_block != NULL && (contig_free_left == NULL || contig_free_right == NULL)){
		unsigned long size_block = *((unsigned long *) curr_block);
		next_block = *((void **) ((long *)curr_block + 1));
		prev_block = *((void **) ((long *)curr_block + 2));

		if(contig_free_left == NULL && ((void *)(((long *)curr_block) + (size_block/8))) == to_free_address){
			// check if current block being considered is on the left of the block to be freed
			contig_free_left = curr_block;
		} 
		if(contig_free_right == NULL && curr_block == ((void *)((long *)to_free_address + (to_free_size/8)))){
			// check if current block is on the right of the block to be freed
			contig_free_right = curr_block;
		}
		
		curr_block = next_block;
	}

	unsigned long final_size = to_free_size;

	if(contig_free_left == NULL && contig_free_right == NULL){
		// if there is no block to the left and right
		if(free_list == NULL){
			// if freelist is empty
			*((unsigned long *) to_free_address) = to_free_size;
			*((void **) ((long *)to_free_address + 1)) = NULL;
			*((void **) ((long *)to_free_address + 2)) = NULL;
			free_list = to_free_address;
		}
		else{
			// if freelist is not empty, insert at the beginning of the freelist
			void *old_start = free_list;
			free_list = to_free_address;
			*((unsigned long *) to_free_address) = to_free_size;
			*((void **) ((long *)to_free_address + 1)) = old_start;
			*((void **) ((long *)to_free_address + 2)) = NULL;

			*((void **) ((long *)old_start + 2)) = to_free_address;
		}
	}
	else if(contig_free_left == NULL && contig_free_right != NULL){
		// if there is no block to the left
		unsigned long right_size = *((unsigned long *) contig_free_right);

		to_free_size += right_size;

		if(free_list == contig_free_right){
			void *old_start = free_list;
			free_list = to_free_address;
			*((unsigned long *) to_free_address) = to_free_size;

			void *old_next_address = *((void **) (old_start + 8));
			*((void **) ((long *)to_free_address + 1)) = old_next_address;
			*((void **) ((long *)to_free_address + 2)) = NULL;

			if(old_next_address != NULL){
				*((void **) ((long *)old_next_address + 2)) = to_free_address;
			}
		}
		else{
			void *prev_of_right = *((void **) ((long *)contig_free_right + 2));
			void *next_of_right = *((void **) ((long *)contig_free_right + 1));

			if(prev_of_right != NULL){
				*((void **) ((long *)prev_of_right + 1)) = next_of_right;
			}
			if(next_of_right != NULL){
				*((void **) ((long *)next_of_right + 2)) = prev_of_right;
			}

			void *old_start = free_list;
			free_list = to_free_address;
			*((unsigned long *) to_free_address) = to_free_size;

			if(old_start != NULL){
				*((void **) ((long *)old_start + 2)) = to_free_address;
			}
			*((void **) ((long *)to_free_address + 1)) = old_start;
			*((void **) ((long *)to_free_address + 2)) = NULL;
		}
	}
	else if(contig_free_left != NULL && contig_free_right == NULL){
		// if there is no block to the right
		unsigned long left_size = *((unsigned long *) contig_free_left);
		to_free_size += left_size;
		to_free_address = contig_free_left;

		if(free_list == contig_free_left){
			*((unsigned long *) free_list) = to_free_size;
		}
		else{
			void *prev_of_left = *((void **) ((long *)contig_free_left + 2));
			void *next_of_left = *((void **) ((long *)contig_free_left + 1));

			if(prev_of_left != NULL){
				*((void **) ((long *)prev_of_left + 1)) = next_of_left;
			}
			if(next_of_left != NULL){
				*((void **) ((long *)next_of_left + 2)) = prev_of_left;
			}

			void *old_start = free_list;
			free_list = to_free_address;
			*((unsigned long *) to_free_address) = to_free_size;

			if(old_start != NULL){
				*((void **) ((long *)old_start + 2)) = to_free_address;
			}
			*((void **) ((long *)to_free_address + 1)) = old_start;
			*((void **) ((long *)to_free_address + 2)) = NULL;
		}
	}
	else{
		// if contiguous memory is present on left and right of the block to be freed
		unsigned long right_size = *((unsigned long *) contig_free_right);
		unsigned long left_size = *((unsigned long *) contig_free_left);

		to_free_size += right_size + left_size;
		to_free_address = contig_free_left;

		if(free_list == contig_free_left){
			*((unsigned long *) free_list) = to_free_size;

			void *next_of_right = *((void **) ((long *)contig_free_right + 1));
			void *prev_of_right = *((void **) ((long *)contig_free_right + 2));

			if(prev_of_right != NULL){
				*((void **) ((long *)prev_of_right + 1)) = next_of_right;
			}
			if(next_of_right != NULL){
				*((void **) ((long *)next_of_right + 2)) = prev_of_right;
			}

			if(*((void **) ((long *)free_list + 1)) != contig_free_right){
			}
			else{
				*((void **) ((long *)to_free_address + 1)) = next_of_right;
			}

			*((void **) ((long *)to_free_address + 2)) = NULL;
		}
		else if(free_list == contig_free_right){
			if(*((void **) ((long *)free_list + 1)) != contig_free_left){
				void *prev_of_left = *((void **) ((long *)contig_free_left + 2));
				void *next_of_left = *((void **) ((long *)contig_free_left + 1));

				if(prev_of_left != NULL){
					*((void **) ((long *)prev_of_left + 1)) = next_of_left;
				}
				if(next_of_left != NULL){
					*((void **) ((long *)next_of_left + 2)) = prev_of_left;
				}

				*((void **) ((long *)contig_free_left + 2)) = NULL;
				*((void **) ((long *)contig_free_left + 1)) = *((void **) ((long *)contig_free_right + 1));

				*((unsigned long *) contig_free_left) = to_free_size;

				free_list = contig_free_left;
			}
			else{
				*((void **) ((long *)contig_free_left + 2)) = NULL;
				free_list = contig_free_left;
				*((unsigned long *) contig_free_left) = to_free_size;
			}
		}
		else{
			void *prev_of_left = *((void **) ((long *)contig_free_left + 2));
			void *next_of_left = *((void **) ((long *)contig_free_left + 1));
			
			if(prev_of_left != NULL){
				*((void **) ((long *)prev_of_left + 1)) = next_of_left;
			}
			if(next_of_left != NULL){
				*((void **) ((long *)next_of_left + 2)) = prev_of_left;
			}

			void *next_of_right = *((void **) ((long *)contig_free_right + 1));
			void *prev_of_right = *((void **) ((long *)contig_free_right + 2));
			
			if(prev_of_right != NULL){
				*((void **) ((long *)prev_of_right + 1)) = next_of_right;
			}
			if(next_of_right != NULL){
				*((void **) ((long *)next_of_right + 2)) = prev_of_right;
			}

			void *old_start = free_list;
			free_list = to_free_address;
			*((unsigned long *) to_free_address) = to_free_size;

			if(old_start != NULL){
				*((void **) ((long *)old_start + 2)) = to_free_address;
			}
			*((void **) ((long *)to_free_address + 1)) = old_start;
			*((void **) ((long *)to_free_address + 2)) = NULL;
		}

	}

	return 0;
}	