#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>

int main(int argc, char *argv[]){
	//take the input operand and perform operation
	unsigned long int input = strtoul(argv[argc - 1], NULL, 10);
	unsigned long int result = 2 * input;

	if(argc < 2){
		perror("Unable to execute\n");
		exit(-1);
	}
	else if(argc == 2){
		// if no other operation is to be performed, print result
		printf("%lu\n", result);	
	}
	else{
		// performing other operations remaining

		// calculate length of result string
		int length = 0;
		unsigned long int res_copy = result;
		while(res_copy){
			length++;
			res_copy /= 10;
		}
		res_copy = result;
		// allocate memory to store result to be passed as an arg
		char *res_string = (char *) malloc((length + 1)*sizeof(char));
		if(res_string == NULL){
			// malloc failed
			perror("Unable to execute\n");
			exit(-1);
		}
		// copy result into allocated str
		for(int i = length - 1; i>=0; i--){
			res_string[i] = '0' + res_copy%10;
			res_copy /= 10;
		}
		res_string[length] = '\0';

		char *args[argc];
		int name_len = strlen(argv[1]) + 3;
		args[0] = (char *) malloc(name_len * sizeof(char));
		args[0][0] = '.';
		args[0][1] = '/';
		strcpy(&args[0][2], argv[1]);
		// initialise args[0] with "./<next_op>", and other args appropriately
		for(int i = 1; i < argc - 2; i++){
			args[i] = argv[i+1];
		}
		args[argc - 2] = res_string;
		args[argc - 1] = NULL;
		// call exec for next operation
		int retval = execvp(args[0], args);
		if(retval < 0){
			// exec failed
			perror("Unable to execute\n");
			exit(-1);
		}
	}
	return 0;
}
