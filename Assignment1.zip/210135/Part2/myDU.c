#include<stdio.h>
#include<stdlib.h>
#include<dirent.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<unistd.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<string.h>

unsigned long int find_size(const char *path){
	// recursive function to find sizes of the directories.
	unsigned long int dir_size = 0;
	struct stat stat_buffer;

	int stat_ret = lstat(path, &stat_buffer);
	if(stat_ret < 0){
		// perror("stat\n");
		perror("Unable to execute\n");
		exit(-1);
	}

	// if it is a link, then do not add its size, else add
	if((stat_buffer.st_mode & S_IFMT) != S_IFLNK) dir_size += stat_buffer.st_size;

	// open the directory for reading contents
	DIR *directory = opendir(path);
	if(directory == NULL){
		// perror("opendir\n");
		perror("Unable to execute\n");
		exit(-1);
	}
	else{
		struct dirent *dirent_buf = readdir(directory);
		// "." and ".." directories to be ignored
		const char *currdir = ".";
		const char *upperdir = "..";

		while(dirent_buf != NULL){
			// while directory is not empty, loop over contents
			if(strcmp(dirent_buf->d_name, currdir) == 0 || strcmp(dirent_buf->d_name, upperdir) == 0){
				dirent_buf = readdir(directory);
				continue;	
				// skip . and ..
			}	

			// generate full path of current file being read using dirent->name and path of containing folder.
			// store it in path_file
			int length = strlen(path);
			int path_length = 2 + length + strlen(dirent_buf->d_name);
			char *path_file = (char *) malloc(path_length * sizeof(char));
			if(path_file == NULL){
				// perror("path_file malloc\n");
				perror("Unable to execute\n");
				exit(-1);
			}
			strcpy(path_file, path);
			int tmplen = strlen(path_file);
			path_file[tmplen] = '/';
			strcpy(&path_file[tmplen + 1], dirent_buf->d_name);
			path_file[path_length - 1] = '\0';

			if(dirent_buf->d_type == DT_LNK){
				// if it is link, indirect it till we reach a folder/file
				struct stat stat_buffer;
				
				int stat_ret = lstat(path_file, &stat_buffer);
				if(stat_ret < 0){
					// lstat failed
					perror("Unable to execute\n");
					exit(-1);
				}

				while((stat_buffer.st_mode & S_IFMT) == S_IFLNK){
					// read the link
					int bufsize = stat_buffer.st_size + 1;
					if(PATH_MAX > bufsize) bufsize = PATH_MAX;
					char *buffer = (char *) malloc(bufsize * sizeof(char));

					int ret_readlink = readlink(path_file, buffer, bufsize);
					if(ret_readlink < 0){
						// perror("readlink\n");
						perror("Unable to execute\n");
						exit(-1);
					}
					buffer[ret_readlink] = '\0';

					// generate the total path of the location pointed to by the link
					int symlink_size = strlen(buffer);

					int total_path_length = symlink_size + length + 4;
					char *total_path = (char *) malloc(total_path_length * sizeof(char));

					strcpy(total_path, path);
					int tmplen = strlen(total_path);
					total_path[tmplen] = '/';
					strcpy(&total_path[tmplen + 1], buffer);
					total_path[total_path_length - 1] = '\0';

					// find type of the location pointed to
					int stat_ret = lstat(total_path, &stat_buffer);
					if(stat_ret < 0){
						// perror("lstat\n");
						perror("Unable to execute\n");
						exit(-1);
					}

					if((stat_buffer.st_mode & S_IFMT) == S_IFDIR){
						// if it is a directory, recursively call find_size()
						dir_size += find_size(total_path);
						free(buffer);
						free(total_path);
						break;
					}
					else if((stat_buffer.st_mode & S_IFMT) == S_IFREG){
						// if file, simply add size
						dir_size += stat_buffer.st_size;
						free(buffer);
						free(total_path);
						break;
					}
					// break the loop in both cases

					free(buffer);
					char *old_path_file = path_file;
					path_file = total_path;
					free(old_path_file);
					// if it is still a link, update the path_file string and continue in the loop
				}
				free(path_file);
			}
			else if(dirent_buf->d_type == DT_DIR){
				// if a directory, call recursively find_path()
				unsigned long subdir_size = find_size(path_file);
				dir_size += subdir_size;
				free(path_file);
			}
			else{
				// if file, add size
				struct stat stat_buffer;
				int stat_ret = lstat(path_file, &stat_buffer);
				if(stat_ret < 0){
					// perror("lstat\n");
					perror("Unable to execute\n");
					exit(-1);
				}
				dir_size += stat_buffer.st_size;
				free(path_file);
			}
			dirent_buf = readdir(directory);
			// read next item in directory
		}
		closedir(directory);
		// close the directory
	}
	return dir_size;
}

int main(int argc, char *argv[]){
	if(argc != 2 && argc != 3){
		// perror("args error\n");
		perror("Unable to execute\n");
		exit(-1);
	}
	
	unsigned long int dir_size = 0;

	int length = strlen(argv[1]);
	char *path = (char *) malloc((length + 4) * sizeof(char));
	if(path == NULL){
		// perror("path malloc error\n");
		perror("Unable to execute\n");
		exit(-1);
	}
	path[0] = '.';
	path[1] = '/';
	strcpy(&path[2], argv[1]);
	path[length + 3] = '\0';

	struct stat stat_buffer;

	int stat_ret = lstat(path, &stat_buffer);
	if(stat_ret < 0){
		// perror("stat\n");
		perror("Unable to execute\n");
		exit(-1);
	}

	if(stat_buffer.st_mode & S_IFMT != S_IFLNK) dir_size += stat_buffer.st_size;

	// open the root directory
	DIR *directory = opendir(path);
	if(directory == NULL){
		// perror("opendir\n");
		perror("Unable to execute\n");
		exit(-1);
	}
	else{
		// start reading the directory entries
		struct dirent *dirent_buf = readdir(directory);
		const char *currdir = ".";
		const char *upperdir = "..";
		while(dirent_buf != NULL){
			if(strcmp(dirent_buf->d_name, currdir) == 0 || strcmp(dirent_buf->d_name, upperdir) == 0){
				// "." and ".." directories to be ignored
				dirent_buf = readdir(directory);
				continue;	
			}	
			// generate the path of the file/directory/link
			int path_length = 4 + length + strlen(dirent_buf->d_name);
			char *path_file = (char *) malloc(path_length * sizeof(char));
			if(path_file == NULL){
				// perror("path_file malloc\n");
				perror("Unable to execute\n");
				exit(-1);
			}
			strcpy(path_file, path);
			int tmplen = strlen(path_file);
			path_file[tmplen] = '/';
			strcpy(&path_file[tmplen + 1], dirent_buf->d_name);
			path_file[path_length - 1] = '\0';

			if(dirent_buf->d_type == DT_LNK){
				// if it is a link, indirect till we dont reach file/dir
				struct stat stat_buffer;
				int stat_ret = lstat(path_file, &stat_buffer);
				if(stat_ret < 0){
					// perror("lstat\n");
					perror("Unable to execute\n");
					exit(-1);
				}

				while((stat_buffer.st_mode & S_IFMT) == S_IFLNK){
					// read the link
					int bufsize = stat_buffer.st_size + 1;
					if(PATH_MAX > bufsize) bufsize = PATH_MAX;
					char *buffer = (char *) malloc(bufsize * sizeof(char));
					int ret_readlink = readlink(path_file, buffer, bufsize);
					if(ret_readlink < 0){
						// perror("readlink\n");
						perror("Unable to execute\n");
						exit(-1);
					}
					buffer[ret_readlink] = '\0';

					int symlink_size = strlen(buffer);
					// generate the complete path to which link points to
					int total_path_length = symlink_size + length + 4;
					char *total_path = (char *) malloc(total_path_length * sizeof(char));

					strcpy(total_path, path);
					int tmplen = strlen(total_path);
					total_path[tmplen] = '/';
					strcpy(&total_path[tmplen + 1], buffer);
					total_path[total_path_length - 1] = '\0';

					int stat_ret = lstat(total_path, &stat_buffer);
					if(stat_ret < 0){
						// perror("lstat\n");
						perror("Unable to execute\n");
						exit(-1);
					}

					if((stat_buffer.st_mode & S_IFMT) == S_IFDIR){
						// if we reach a directory, call find_size() and break
						dir_size += find_size(total_path);
						free(buffer);
						free(total_path);
						break;
					}
					else if((stat_buffer.st_mode & S_IFMT) == S_IFREG){
						// if we reach file, simply add its size and break
						dir_size += stat_buffer.st_size;
						free(buffer);
						free(total_path);
						break;
					}

					free(buffer);
					char *old_path_file = path_file;
					path_file = total_path;
					free(old_path_file);
					// if it is still a link, update the path and continue indirection
				}
				free(path_file);
			}
			else if(dirent_buf->d_type == DT_DIR){
				// if it is directory
				if(argc == 3){
					// if argc == 3 means we are in a child process, so don't fork. Call find_size()
					dir_size += find_size(path_file);
				}
				else{
					// else we are in the parent process (of the Root directory)
					// create pipe for inter process communication and fork-exec
					int comm_pipe[2];
					int ret_pipe = pipe(comm_pipe);

					if(ret_pipe < 0){
						// perror("pipe\n");
						perror("Unable to execute\n");
						exit(-1);
					}

					int fork_ret = fork();

					if(fork_ret < 0){
						// perror("fork\n");
						perror("Unable to execute\n");
						exit(-1);
					}
					else if(fork_ret == 0){
						// child process, here call exec with the sub-directory path as arg, and argc = 3
						// use an extra dummy 'temparg' to make argc = 3
						close(comm_pipe[0]);
						close(1);
						// close stdout and connect pipe write end to stdout so that printf leads to writes to pipe
						dup2(comm_pipe[1], 1);
						const char *temparg = "foo";
						int ret_exec = execl(argv[0], argv[0], &path_file[2], temparg, (char *) NULL);
						if(ret_exec < 0){
							// perror("exec\n");
							perror("Unable to execute\n");
							exit(-1);
						}
					}
					else{
						close(comm_pipe[1]);
						int wait_ret_status;
						waitpid(fork_ret, &wait_ret_status, 0);
						if(WEXITSTATUS(wait_ret_status) != 0){
							// perror("Error in child process\n");
							perror("Unable to execute\n");
							exit(-1);
						}
						// allocate buffer to collect the result printed by child
						char *num_buf = (char *) malloc(256 * sizeof(char));
						if(num_buf == NULL){
							// perror("numbuf malloc\n");
							perror("Unable to execute\n");
							exit(-1);
						}
						char char_buf;
						int i = 0;
						while(read(comm_pipe[0], &char_buf, 1) > 0){
							num_buf[i] = char_buf;
							i++;
							if(i == 256){		
								// perror("outpur long\n");					
								perror("Unable to execute\n");
								exit(-1);
							}	
						}
						// get size returned by child
						unsigned long int child_size = strtoul(num_buf, NULL, 10);
						dir_size += child_size;
						free(num_buf);
					}	
				}
				free(path_file);
			}
			else{
				// it is a regular file
				struct stat stat_buffer;
				int stat_ret = lstat(path_file, &stat_buffer);
				if(stat_ret < 0){
					// perror("lstat\n");
					perror("Unable to execute\n");
					exit(-1);
				}
				dir_size += stat_buffer.st_size;
				// simply add its file size
				free(path_file);
			}
			dirent_buf = readdir(directory);
			// read next entry of the directory
		}
		closedir(directory);
		// close the directory
	}
	free(path);

	printf("%lu\n", dir_size);
	// print the result

	return 0;
}
