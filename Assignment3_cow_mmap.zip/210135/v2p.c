#include <types.h>
#include <mmap.h>
#include <fork.h>
#include <v2p.h>
#include <page.h>

/* 
 * You may define macros and other helper functions here
 * You must not declare and use any static/global variables 
 * */
#define __PAGE_SIZE 1024*4
#define __MAX_LENGTH_ARG 1024*1024*2

void insert_after(struct vm_area *prev, struct vm_area *middle, struct vm_area *vm_ptr){
    if(prev == NULL){
        // can never happen! (dummy always there)
        return;
    }
    else{
        prev->vm_next = middle;
        middle->vm_next = vm_ptr;
    }
}

int length_ceil(int len){
    return ((len - 1 + __PAGE_SIZE)/(__PAGE_SIZE))*(__PAGE_SIZE);
}

static inline void invlpg_my(u64 addr)
{
    /* Clobber memory to avoid optimizer re-ordering access before invlpg, which may cause nasty bugs. */
    // asm volatile ( "invlpg (%0)" : : "b"(m) : "memory" );
    asm volatile("invlpg (%0)" ::"r" (addr) : "memory");
}

// handle_cow_mem_reassignment(addr, new_ctx, ctx, access_flags);
long handle_cow_mem_reassignment(u64 addr, struct exec_context *new_ctx, struct exec_context *ctx, u32 access_flags){
    // printk("REACHED HANDLE COW MEM REASSIGNMENT\n");
    // asm volatile("movq %%cr3, %%rax;" 
    //   "movq %%rax, %%cr3;"
    //  :         /* output */
    //  :         /* input */
    //  :"%rax"         /* clobbered register */
    // );
    
    // printk("%x\n", addr);
    u64 cr3_contents = ctx->pgd;
    u64 cr3_contents_new = new_ctx->pgd;
    // printk("cr3: %x\n", cr3_contents);
    // u64 cr3_pfn_number = cr3_contents>>12;
    u64 cr3_pfn_number = cr3_contents;
    u64 cr3_pfn_number_new = cr3_contents_new;

    void *virtual_pt_lvl_0 = osmap(cr3_pfn_number);
    void *virtual_pt_lvl_0_new = osmap(cr3_pfn_number_new);
    // printk("vaddr of pt base: %x\n", virtual_pt_lvl_0);

    u64 lvl_0_offset = ((addr>>39) & 511);
    u64 lvl_1_offset = ((addr>>30) & 511);
    u64 lvl_2_offset = ((addr>>21) & 511);
    u64 lvl_3_offset = ((addr>>12) & 511);

    u64 lvl_0_contents = *(((u64 *) virtual_pt_lvl_0) + lvl_0_offset);
    u64 lvl_0_contents_new = *(((u64 *) virtual_pt_lvl_0_new) + lvl_0_offset);
    // printk("lvl0 contents : %x\n", lvl_0_contents);

    if((lvl_0_contents & 1ULL) == 0){
        invlpg_my(addr);
        return 1;
    }
    else if((lvl_0_contents_new & 1ULL) == 0){
        // printk("first level not allocated\n");
        u64 lvl_1_pfn_new = os_pfn_alloc(OS_PT_REG);
        if(lvl_1_pfn_new == 0){
            return -EINVAL;
        }

        // printk("ref count : %d\n", get_pfn_refcount(lvl_1_pfn_new));

        char *new_pfn_vaddr = osmap(lvl_1_pfn_new);
        for(int offset = 0; offset < __PAGE_SIZE; offset++){
            *(new_pfn_vaddr + offset) = 0;
        }

        // printk("l1 pfn : %x\n", lvl_1_pfn);
        *(((u64 *) virtual_pt_lvl_0_new) + lvl_0_offset) = ((lvl_1_pfn_new<<12) | 0x19);
        invlpg_my((u64)(((u64 *) virtual_pt_lvl_0) + lvl_0_offset));
        // printk("lvl0 contents after modification: %x\n", *(((u64 *) virtual_pt_lvl_0) + lvl_0_offset));
    }

    u64 lvl_1_pfn = lvl_0_contents>>12;
    lvl_0_contents_new = *(((u64 *) virtual_pt_lvl_0_new) + lvl_0_offset);
    u64 lvl_1_pfn_new = lvl_0_contents_new>>12;
    // printk("%x\n", lvl_1_pfn);
    void *virtual_pt_lvl_1 = osmap(lvl_1_pfn);
    void *virtual_pt_lvl_1_new = osmap(lvl_1_pfn_new);
    u64 lvl_1_contents = *(((u64 *) virtual_pt_lvl_1) + lvl_1_offset);
    u64 lvl_1_contents_new = *(((u64 *) virtual_pt_lvl_1_new) + lvl_1_offset);

    if((lvl_1_contents & 1ULL) == 0){
        invlpg_my(addr);
        return 1;
    }
    else if((lvl_1_contents_new & 1ULL) == 0){
        // printk("second level not allocated\n");
        u64 lvl_2_pfn_new = os_pfn_alloc(OS_PT_REG);
        if(lvl_2_pfn_new == 0){
            return -EINVAL;
        }

        char *new_pfn_vaddr = osmap(lvl_2_pfn_new);
        for(int offset = 0; offset < __PAGE_SIZE; offset++){
            *(new_pfn_vaddr + offset) = 0;
        }

        // printk("l2 pfn : %x\n", lvl_2_pfn);
        *(((u64 *) virtual_pt_lvl_1_new) + lvl_1_offset) = ((lvl_2_pfn_new<<12) | 0x19);
        invlpg_my((u64)(((u64 *) virtual_pt_lvl_1) + lvl_1_offset));
    }

    u64 lvl_2_pfn = lvl_1_contents>>12;
    lvl_1_contents_new = *(((u64 *) virtual_pt_lvl_1_new) + lvl_1_offset);
    u64 lvl_2_pfn_new = lvl_1_contents_new>>12;
    void *virtual_pt_lvl_2 = osmap(lvl_2_pfn);
    void *virtual_pt_lvl_2_new = osmap(lvl_2_pfn_new);
    u64 lvl_2_contents = *(((u64 *) virtual_pt_lvl_2) + lvl_2_offset);
    u64 lvl_2_contents_new = *(((u64 *) virtual_pt_lvl_2_new) + lvl_2_offset);

    if((lvl_2_contents & 1ULL) == 0){
        invlpg_my(addr);
        return 1;
    }
    else if((lvl_2_contents_new & 1ULL) == 0){
        // printk("third level not allocated\n");
        u64 lvl_3_pfn_new = os_pfn_alloc(OS_PT_REG);
        if(lvl_3_pfn_new == 0){
            return -EINVAL;
        }

        char *new_pfn_vaddr = osmap(lvl_3_pfn_new);
        for(int offset = 0; offset < __PAGE_SIZE; offset++){
            *(new_pfn_vaddr + offset) = 0;
        }

        *(((u64 *) virtual_pt_lvl_2_new) + lvl_2_offset) = ((lvl_3_pfn_new<<12) | 0x19);
        invlpg_my((u64)(((u64 *) virtual_pt_lvl_2) + lvl_2_offset));
    }

    u64 lvl_3_pfn = lvl_2_contents>>12;
    lvl_2_contents_new = *(((u64 *) virtual_pt_lvl_2_new) + lvl_2_offset);
    u64 lvl_3_pfn_new = lvl_2_contents_new>>12;
    void *virtual_pt_lvl_3 = osmap(lvl_3_pfn);
    void *virtual_pt_lvl_3_new = osmap(lvl_3_pfn_new);
    u64 lvl_3_contents = *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset);
    u64 lvl_3_contents_new = *(((u64 *) virtual_pt_lvl_3_new) + lvl_3_offset);

    if((lvl_3_contents & 1ULL) == 0){
        invlpg_my(addr);
        return 1;
    }
    else if((lvl_3_contents_new & 1ULL) == 0){
        // printk("actual level not allocated\n");
        u64 perms = 0x11;

        u64 pfn_number = *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset);
        pfn_number = pfn_number>>12;
        // printk("refcount before get: %d of pfn %x, vaddr %x\n", get_pfn_refcount(pfn_number), pfn_number, addr);
        get_pfn(pfn_number);
        // printk("refcount after get: %d of pfn %x, vaddr %x\n", get_pfn_refcount(pfn_number), pfn_number, addr);

        *(((u64 *) virtual_pt_lvl_3_new) + lvl_3_offset) = ((pfn_number<<12) | perms);
        *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset) = ((pfn_number<<12) | perms);
        invlpg_my((u64)(((u64 *) virtual_pt_lvl_3) + lvl_3_offset));
        invlpg_my((u64)(((u64 *) virtual_pt_lvl_3_new) + lvl_3_offset));

        invlpg_my(addr);
        return 1;
    }

    // printk("returned 1\n");
    invlpg_my(addr);
    return 1;
}

long do_page_table_walk(u64 addr, struct exec_context *current, struct vm_area *vma){
    // asm volatile("movq %%cr3, %%rax;" 
    //   "movq %%rax, %%cr3;"
    //  :         /* output */
    //  :         /* input */
    //  :"%rax"         /* clobbered register */
    // );
    
    // printk("%x\n", addr);
    u64 cr3_contents = current->pgd;
    // printk("cr3: %x\n", cr3_contents);
    // u64 cr3_pfn_number = cr3_contents>>12;
    u64 cr3_pfn_number = cr3_contents;

    void *virtual_pt_lvl_0 = osmap(cr3_pfn_number);
    // printk("vaddr of pt base: %x\n", virtual_pt_lvl_0);

    u64 lvl_0_offset = ((addr>>39) & 511);
    u64 lvl_1_offset = ((addr>>30) & 511);
    u64 lvl_2_offset = ((addr>>21) & 511);
    u64 lvl_3_offset = ((addr>>12) & 511);

    u64 lvl_0_contents = *(((u64 *) virtual_pt_lvl_0) + lvl_0_offset);
    // printk("lvl0 contents : %x\n", lvl_0_contents);

    if((lvl_0_contents & 1ULL) == 0){
        // printk("first level not allocated\n");
        u64 lvl_1_pfn = os_pfn_alloc(OS_PT_REG);
        if(lvl_1_pfn == 0){
            return -EINVAL;
        }

        char *new_pfn_vaddr = osmap(lvl_1_pfn);
        for(int offset = 0; offset < __PAGE_SIZE; offset++){
            *(new_pfn_vaddr + offset) = 0;
        }

        // printk("l1 pfn : %x\n", lvl_1_pfn);
        *(((u64 *) virtual_pt_lvl_0) + lvl_0_offset) = ((lvl_1_pfn<<12) | 0x19);
        invlpg_my((u64)(((u64 *) virtual_pt_lvl_0) + lvl_0_offset));
        // printk("lvl0 contents after modification: %x\n", *(((u64 *) virtual_pt_lvl_0) + lvl_0_offset));


        void *virtual_pt_lvl_1 = osmap(lvl_1_pfn);
        u64 lvl_2_pfn = os_pfn_alloc(OS_PT_REG);
        if(lvl_2_pfn == 0){
            return -EINVAL;
        }

        new_pfn_vaddr = osmap(lvl_2_pfn);
        for(int offset = 0; offset < __PAGE_SIZE; offset++){
            *(new_pfn_vaddr + offset) = 0;
        }

        // printk("l2 pfn : %x\n", lvl_2_pfn);
        *(((u64 *) virtual_pt_lvl_1) + lvl_1_offset) = ((lvl_2_pfn<<12) | 0x19);
        invlpg_my((u64)(((u64 *) virtual_pt_lvl_1) + lvl_1_offset));

        void *virtual_pt_lvl_2 = osmap(lvl_2_pfn);
        u64 lvl_3_pfn = os_pfn_alloc(OS_PT_REG);
        if(lvl_3_pfn == 0){
            return -EINVAL;
        }

        new_pfn_vaddr = osmap(lvl_3_pfn);
        for(int offset = 0; offset < __PAGE_SIZE; offset++){
            *(new_pfn_vaddr + offset) = 0;
        }

        // printk("l3 pfn : %x\n", lvl_3_pfn);
        *(((u64 *) virtual_pt_lvl_2) + lvl_2_offset) = ((lvl_3_pfn<<12) | 0x19);
        invlpg_my((u64)(((u64 *) virtual_pt_lvl_2) + lvl_2_offset));

        void *virtual_pt_lvl_3 = osmap(lvl_3_pfn);
        u64 pfn_number = os_pfn_alloc(USER_REG);
        if(pfn_number == 0){
            return -EINVAL;
        }
        // printk("final phy. addr %x\n", pfn_number);
        u64 perms;
        if(vma->access_flags & PROT_WRITE){
            perms = 0x19;
        }
        else perms = 0x11;

        *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset) = ((pfn_number<<12) | perms);
        invlpg_my((u64)(((u64 *) virtual_pt_lvl_3) + lvl_3_offset));
        invlpg_my(addr);
        return 1;
    }

    u64 lvl_1_pfn = lvl_0_contents>>12;
    // printk("%x\n", lvl_1_pfn);
    void *virtual_pt_lvl_1 = osmap(lvl_1_pfn);
    u64 lvl_1_contents = *(((u64 *) virtual_pt_lvl_1) + lvl_1_offset);
    // printk("lvl1 contents : %x\n", lvl_1_contents);

    if((lvl_1_contents & 1ULL) == 0){
        // printk("second level not allocated\n");
        u64 lvl_2_pfn = os_pfn_alloc(OS_PT_REG);
        if(lvl_2_pfn == 0){
            return -EINVAL;
        }

        char *new_pfn_vaddr = osmap(lvl_2_pfn);
        for(int offset = 0; offset < __PAGE_SIZE; offset++){
            *(new_pfn_vaddr + offset) = 0;
        }

        // printk("l2 pfn : %x\n", lvl_2_pfn);
        *(((u64 *) virtual_pt_lvl_1) + lvl_1_offset) = ((lvl_2_pfn<<12) | 0x19);
        invlpg_my((u64)(((u64 *) virtual_pt_lvl_1) + lvl_1_offset));

        void *virtual_pt_lvl_2 = osmap(lvl_2_pfn);
        u64 lvl_3_pfn = os_pfn_alloc(OS_PT_REG);
        if(lvl_3_pfn == 0){
            return -EINVAL;
        }

        new_pfn_vaddr = osmap(lvl_3_pfn);
        for(int offset = 0; offset < __PAGE_SIZE; offset++){
            *(new_pfn_vaddr + offset) = 0;
        }

        // printk("l3 pfn : %x\n", lvl_3_pfn);
        *(((u64 *) virtual_pt_lvl_2) + lvl_2_offset) = ((lvl_3_pfn<<12) | 0x19);
        invlpg_my((u64)(((u64 *) virtual_pt_lvl_2) + lvl_2_offset));

        void *virtual_pt_lvl_3 = osmap(lvl_3_pfn);
        u64 pfn_number = os_pfn_alloc(USER_REG);
        if(pfn_number == 0){
            return -EINVAL;
        }

        // printk("final phy. addr %x\n", pfn_number);
        u64 perms;
        if(vma->access_flags & PROT_WRITE){
            perms = 0x19;
        }
        else perms = 0x11;

        *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset) = ((pfn_number<<12) | perms);
        invlpg_my((u64)(((u64 *) virtual_pt_lvl_3) + lvl_3_offset));
        invlpg_my(addr);
        return 1;
    }

    u64 lvl_2_pfn = lvl_1_contents>>12;
    void *virtual_pt_lvl_2 = osmap(lvl_2_pfn);
    u64 lvl_2_contents = *(((u64 *) virtual_pt_lvl_2) + lvl_2_offset);
    // printk("lvl2 contents : %x\n", lvl_2_contents);

    if((lvl_2_contents & 1ULL) == 0){
        // printk("third level not allocated\n");
        u64 lvl_3_pfn = os_pfn_alloc(OS_PT_REG);
        if(lvl_3_pfn == 0){
            return -EINVAL;
        }

        char *new_pfn_vaddr = osmap(lvl_3_pfn);
        for(int offset = 0; offset < __PAGE_SIZE; offset++){
            *(new_pfn_vaddr + offset) = 0;
        }

        *(((u64 *) virtual_pt_lvl_2) + lvl_2_offset) = ((lvl_3_pfn<<12) | 0x19);
        invlpg_my((u64)(((u64 *) virtual_pt_lvl_2) + lvl_2_offset));
        // printk("lvl2 contents new: %x\n", *(((u64 *) virtual_pt_lvl_2) + lvl_2_offset));

        void *virtual_pt_lvl_3 = osmap(lvl_3_pfn);
        u64 pfn_number = os_pfn_alloc(USER_REG);
        if(pfn_number == 0){
            return -EINVAL;
        }

        u64 perms;
        if(vma->access_flags & PROT_WRITE){
            perms = 0x19;
        }
        else perms = 0x11;

        *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset) = ((pfn_number<<12) | perms);
        invlpg_my((u64)(((u64 *) virtual_pt_lvl_3) + lvl_3_offset));
        // printk("lvl3 contents new: %x\n", *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset));

        invlpg_my(addr);
        return 1;
    }

    u64 lvl_3_pfn = lvl_2_contents>>12;
    void *virtual_pt_lvl_3 = osmap(lvl_3_pfn);
    u64 lvl_3_contents = *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset);
    // printk("lvl3 contents : %x\n", lvl_3_contents);

    if((lvl_3_contents & 1ULL) == 0){
        // printk("actual level not allocated\n");
        u64 pfn_number = os_pfn_alloc(USER_REG);
        if(pfn_number == 0){
            return -EINVAL;
        }
        // printk("User level - pfn ref count: %d\n", get_pfn_refcount(pfn_number));
        u64 perms;
        if(vma->access_flags & PROT_WRITE){
            perms = 0x19;
        }
        else perms = 0x11;

        *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset) = ((pfn_number<<12) | perms);
        // printk("lvl3 contents new: %x\n", *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset));

        invlpg_my((u64)(((u64 *) virtual_pt_lvl_3) + lvl_3_offset));
        invlpg_my(addr);
        return 1;
    }

    // printk("returned 1\n");
    invlpg_my(addr);
    return 1;
}

long free_physical_allocation(u64 addr, struct exec_context *current){
    // asm volatile("movq %%cr3, %%rax;" 
    //   "movq %%rax, %%cr3;"
    //  :         /* output */
    //  :         /* input */
    //  :"%rax"         /* clobbered register */
    // );

    // printk("free physical allocation called : vaddr %x, pid %d\n", addr, current->pid);
    // int cnter1 = 0;
    // while(cnter1 < 100){
    //     // printk(" ");
    //     cnter1+=3;
    // }
    // printk("\n");
    u64 cr3_contents = current->pgd;
    // u64 cr3_pfn_number = cr3_contents>>12;
    u64 cr3_pfn_number = cr3_contents;
    void *virtual_pt_lvl_0 = osmap(cr3_pfn_number);

    u64 lvl_0_offset = addr>>39;
    u64 lvl_1_offset = ((addr>>30) & 511);
    u64 lvl_2_offset = ((addr>>21) & 511);
    u64 lvl_3_offset = ((addr>>12) & 511);

    u64 lvl_0_contents = *(((u64 *) virtual_pt_lvl_0) + lvl_0_offset);

    if((lvl_0_contents & 1ULL) == 0){
        // printk("return lvl0\n");
        invlpg_my(addr);
        return 1;
    }

    u64 lvl_1_pfn = lvl_0_contents>>12;
    void *virtual_pt_lvl_1 = osmap(lvl_1_pfn);
    u64 lvl_1_contents = *(((u64 *) virtual_pt_lvl_1) + lvl_1_offset);

    if((lvl_1_contents & 1ULL) == 0){
        // printk("return lvl1\n");
        invlpg_my(addr);
        return 1;
    }

    u64 lvl_2_pfn = lvl_1_contents>>12;
    void *virtual_pt_lvl_2 = osmap(lvl_2_pfn);
    u64 lvl_2_contents = *(((u64 *) virtual_pt_lvl_2) + lvl_2_offset);

    if((lvl_2_contents & 1ULL) == 0){
        // printk("return lvl2\n");
        invlpg_my(addr);
        return 1;
    }

    u64 lvl_3_pfn = lvl_2_contents>>12;
    void *virtual_pt_lvl_3 = osmap(lvl_3_pfn);
    u64 lvl_3_contents = *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset);

    if((lvl_3_contents & 1ULL) == 0){
        // printk("return lvl3\n");
        invlpg_my(addr);
        return 1;
    }

    // *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset) = (*(((u64 *) virtual_pt_lvl_3) + lvl_3_offset)) & 0xFFFFFFFE;
    *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset) = 0;
    invlpg_my((u64)(((u64 *) virtual_pt_lvl_3) + lvl_3_offset));
    // ################################### part 2 ########################################################################
    // os_pfn_free(USER_REG, (lvl_3_contents>>12));
    // ###################################################################################################################

    // ################################### part 3 ########################################################################
    // printk("putting %x at pid : %d, in munmap vaddr: %x\n",(lvl_3_contents>>12), current->pid, addr);
    // printk("refcount before put : %d vaddr %x\n", get_pfn_refcount((lvl_3_contents>>12)), addr);
    // int cnter = 0;
    // while(cnter < 100){
    //     // printk(" ");
    //     cnter+=4;
    // }
    // printk("\n");
    put_pfn((lvl_3_contents>>12));
    // printk("refcount after put : %d vaddr \n", get_pfn_refcount((lvl_3_contents>>12)), addr);

    if(get_pfn_refcount((lvl_3_contents>>12)) == 0){
        os_pfn_free(USER_REG, (lvl_3_contents>>12));
    }
    // ###################################################################################################################

    invlpg_my(addr);
    return 1;
}


long modify_physical_allocation(u64 addr, struct exec_context *current, u32 new_perm){
    // asm volatile("movq %%cr3, %%rax;" 
    //   "movq %%rax, %%cr3;"
    //  :         /* output */
    //  :         /* input */
    //  :"%rax"         /* clobbered register */
    // );
    
    u32 write = new_perm & PROT_WRITE;

    u64 cr3_contents = current->pgd;
    // u64 cr3_pfn_number = cr3_contents>>12;
    u64 cr3_pfn_number = cr3_contents;

    void *virtual_pt_lvl_0 = osmap(cr3_pfn_number);

    u64 lvl_0_offset = addr>>39;
    u64 lvl_1_offset = ((addr>>30) & 511);
    u64 lvl_2_offset = ((addr>>21) & 511);
    u64 lvl_3_offset = ((addr>>12) & 511);

    u64 lvl_0_contents = *(((u64 *) virtual_pt_lvl_0) + lvl_0_offset);

    if((lvl_0_contents & 1ULL) == 0){
        invlpg_my(addr);
        return 1;
    }

    u64 lvl_1_pfn = lvl_0_contents>>12;
    void *virtual_pt_lvl_1 = osmap(lvl_1_pfn);
    u64 lvl_1_contents = *(((u64 *) virtual_pt_lvl_1) + lvl_1_offset);

    if((lvl_1_contents & 1ULL) == 0){
        invlpg_my(addr);
        return 1;
    }

    u64 lvl_2_pfn = lvl_1_contents>>12;
    void *virtual_pt_lvl_2 = osmap(lvl_2_pfn);
    u64 lvl_2_contents = *(((u64 *) virtual_pt_lvl_2) + lvl_2_offset);

    if((lvl_2_contents & 1ULL) == 0){
        invlpg_my(addr);
        return 1;
    }

    u64 lvl_3_pfn = lvl_2_contents>>12;
    void *virtual_pt_lvl_3 = osmap(lvl_3_pfn);
    u64 lvl_3_contents = *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset);

    if((lvl_3_contents & 1ULL) == 0){
        invlpg_my(addr);
        return 1;
    }

    // ################################################## part 2 ###############################################################
    // if(!write) *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset) = *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset) & 0xFFFFFFF7;
    // else *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset) = *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset) | 0x8;
    // #########################################################################################################################

    // ################################################## part 3 ###############################################################
    if(!write) *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset) = *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset) & 0xFFFFFFF7;
    else {
        u64 pfn_number = *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset);
        pfn_number = pfn_number >> 12;
        if(get_pfn_refcount(pfn_number) == 1){
            *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset) = *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset) | 0x8;
        }
    }
    // #########################################################################################################################

    invlpg_my((u64)(((u64 *) virtual_pt_lvl_3) + lvl_3_offset));

    invlpg_my(addr);
    return 1;
}

/**
 * mprotect System call Implementation.
 */
long vm_area_mprotect(struct exec_context *current, u64 addr, int length, int prot)
{
    if(current == NULL){
        // printk("ctx null\n");
        return -EINVAL;
    }
    if(addr < MMAP_AREA_START || addr > MMAP_AREA_END){
        // printk("invalid addr arg\n");
        return -EINVAL;
    }
    if(((void *)addr) != NULL && addr + length > MMAP_AREA_END){
        // ASK?????
        // printk("invalid addr arg range\n");
        return -EINVAL;
    }
    if(length < 0 || length > __MAX_LENGTH_ARG){
        // printk("invalid length arg\n");
        return -EINVAL;
    }
    if(prot != PROT_READ && prot != (PROT_READ | PROT_WRITE)){
        // printk("invalid prot arg\n");
        return -EINVAL;
    }

    length = length_ceil(length);

    u64 end_addr = addr + length;

    struct vm_area *prev = NULL;
    struct vm_area *curr_vma = current->vm_area;

    // struct vm_area *vm_ptr = current->vm_area;
    // while(vm_ptr != NULL){
    //     // printk("%x to %x perm %d\n", vm_ptr->vm_start, vm_ptr->vm_end, vm_ptr->access_flags);
    //     vm_ptr = vm_ptr->vm_next;
    // }

    while(curr_vma != NULL){
        // struct vm_area *next = curr_vma->vm_next;

        if(curr_vma->vm_start == MMAP_AREA_START){
            prev = curr_vma;
            curr_vma = curr_vma->vm_next;
        }
        else if(curr_vma->vm_start >= addr && curr_vma->vm_end < end_addr){
            // printk("\n curr_vma->vm_start >= addr && curr_vma->vm_end < end_addr \n"); 
            curr_vma->access_flags = prot;
            // ###################################### part-2 ##############################################################

            for(u64 free_ptr = curr_vma->vm_start; free_ptr < curr_vma->vm_end; free_ptr += __PAGE_SIZE){
                modify_physical_allocation(free_ptr, current, prot);
            }

            // ############################################################################################################
            prev = curr_vma;
            curr_vma = curr_vma->vm_next;
        }
        else if(curr_vma->vm_start >= addr && curr_vma->vm_end >= end_addr && curr_vma->vm_start < end_addr){
            // printk("\n curr_vma->vm_start >= addr && curr_vma->vm_end >= end_addr \n"); 
            if(curr_vma->vm_end == end_addr){
                // printk("curr_vma->vm_end == end_addr \n");
                curr_vma->access_flags = prot;
                // ###################################### part-2 ##############################################################

                for(u64 free_ptr = curr_vma->vm_start; free_ptr < curr_vma->vm_end; free_ptr += __PAGE_SIZE){
                    modify_physical_allocation(free_ptr, current, prot);
                }

                // ############################################################################################################
                prev = curr_vma;
                curr_vma = curr_vma->vm_next;
            }
            else{
                // split into two
                // printk("else\n");
                struct vm_area *new_vma = os_alloc(sizeof(struct vm_area));
                if(new_vma == NULL){
                    // printk("os_alloc failed in vmarea\n");
                    return -EINVAL;
                }
                new_vma->access_flags = curr_vma->access_flags;
                curr_vma->access_flags = prot;
                // ###################################### part-2 ##############################################################

                for(u64 free_ptr = curr_vma->vm_start; free_ptr < end_addr; free_ptr += __PAGE_SIZE){
                    modify_physical_allocation(free_ptr, current, prot);
                }

                // ############################################################################################################
                new_vma->vm_start = end_addr;
                new_vma->vm_end = curr_vma->vm_end;
                curr_vma->vm_end = end_addr;

                new_vma->vm_next = curr_vma->vm_next;
                curr_vma->vm_next = new_vma;

                stats->num_vm_area++;

                prev = new_vma;
                curr_vma = new_vma->vm_next;
            }
        }
        else if(curr_vma->vm_start < addr && curr_vma->vm_end < end_addr && addr < curr_vma->vm_end){
            // split into two
            // printk("\n curr_vma->vm_start < addr && curr_vma->vm_end < end_addr \n"); 

            struct vm_area *new_vma = os_alloc(sizeof(struct vm_area));
            if(new_vma == NULL){
                // printk("os_alloc failed in vmarea\n");
                return -EINVAL;
            }
            new_vma->access_flags = prot;

            new_vma->vm_start = addr;
            new_vma->vm_end = curr_vma->vm_end;
            // ###################################### part-2 ##############################################################

            for(u64 free_ptr = addr; free_ptr < curr_vma->vm_end; free_ptr += __PAGE_SIZE){
                modify_physical_allocation(free_ptr, current, prot);
            }

            // ############################################################################################################

            curr_vma->vm_end = addr;

            new_vma->vm_next = curr_vma->vm_next;
            curr_vma->vm_next = new_vma;

            stats->num_vm_area++;

            prev = new_vma;
            curr_vma = new_vma->vm_next;
        }
        else if(curr_vma->vm_start < addr && curr_vma->vm_end >= end_addr){
            // curr_vma->vm_start < addr && curr_vma->vm_end >= end_addr
            // printk("\n curr_vma->vm_start < addr && curr_vma->vm_end >= end_addr \n"); 
            
            if(curr_vma->vm_end == end_addr){
                // split into two
                // printk("curr_vma->vm_end == end_addr\n");
                struct vm_area *new_vma = os_alloc(sizeof(struct vm_area));
                if(new_vma == NULL){
                    // printk("os_alloc failed in vmarea\n");
                    return -EINVAL;
                }
                new_vma->access_flags = prot;

                new_vma->vm_start = addr;
                new_vma->vm_end = curr_vma->vm_end;
                // ###################################### part-2 ##############################################################

                for(u64 free_ptr = addr; free_ptr < curr_vma->vm_end; free_ptr += __PAGE_SIZE){
                    modify_physical_allocation(free_ptr, current, prot);
                }

                // ############################################################################################################
                curr_vma->vm_end = addr;

                new_vma->vm_next = curr_vma->vm_next;
                curr_vma->vm_next = new_vma;

                stats->num_vm_area++;

                prev = new_vma;
                curr_vma = new_vma->vm_next;
            }
            else{
                // split into 3 -=====- curr - left - right
                // printk("else\n");
                struct vm_area *new_vma_left = os_alloc(sizeof(struct vm_area));
                struct vm_area *new_vma_right = os_alloc(sizeof(struct vm_area));
                if(new_vma_left == NULL || new_vma_right == NULL){
                    // printk("os_alloc failed in vmarea\n");
                    return -EINVAL;
                }
                new_vma_left->access_flags = prot;
                new_vma_left->vm_start = addr;
                new_vma_left->vm_end = end_addr;
                // ###################################### part-2 ##############################################################

                for(u64 free_ptr = addr; free_ptr < end_addr; free_ptr += __PAGE_SIZE){
                    modify_physical_allocation(free_ptr, current, prot);
                }

                // ############################################################################################################

                new_vma_right->access_flags = curr_vma->access_flags;
                new_vma_right->vm_start = end_addr;
                new_vma_right->vm_end = curr_vma->vm_end;

                curr_vma->vm_end = addr;

                new_vma_right->vm_next = curr_vma->vm_next;
                curr_vma->vm_next = new_vma_left;
                new_vma_left->vm_next = new_vma_right;

                stats->num_vm_area+=2;

                prev = new_vma_right;
                curr_vma = new_vma_right->vm_next;
            }
        }
        else{
            prev = curr_vma;
            curr_vma = curr_vma->vm_next;
        }
    }

    // check if merge possible
    curr_vma = current->vm_area;
    prev = NULL;

    while(curr_vma != NULL){   
        if(prev != NULL && curr_vma != NULL){
            if(prev->access_flags == curr_vma->access_flags && prev->vm_end == curr_vma->vm_start){
                // merge
                prev->vm_end = curr_vma->vm_end;
                prev->vm_next = curr_vma->vm_next;
                os_free(curr_vma, sizeof(struct vm_area));
                stats->num_vm_area--;
                curr_vma = prev;
            }
        }

        prev = curr_vma;
        curr_vma = curr_vma->vm_next;
    }

    // vm_ptr = current->vm_area;
    // while(vm_ptr != NULL){
    //     // printk("%x to %x perm %d\n", vm_ptr->vm_start, vm_ptr->vm_end, vm_ptr->access_flags);
    //     vm_ptr = vm_ptr->vm_next;
    // }

    return 0;
}

/**
 * mmap system call implementation.
 */
long vm_area_map(struct exec_context *current, u64 addr, int length, int prot, int flags)
{
    // check validity of the inputs
    if(current == NULL){
        // printk("ctx null\n");
        return -EINVAL;
    }
    if(((void *)addr != NULL) && (addr < MMAP_AREA_START || addr > MMAP_AREA_END)){
        // printk("invalid addr arg\n");
        return -EINVAL;
    }
    if(((void *)addr != NULL) && addr + length > MMAP_AREA_END){
        // ASK?????
        // printk("invalid addr arg range\n");
        return -EINVAL;
    }
    if(length < 0 || length > __MAX_LENGTH_ARG){
        // printk("invalid length arg\n");
        return -EINVAL;
    }
    if(prot != PROT_READ && prot != (PROT_READ | PROT_WRITE)){
        // printk("invalid prot arg\n");
        return -EINVAL;
    }
    if(flags != 0 && flags != MAP_FIXED){
        // printk("invalid flag arg\n");
        return -EINVAL;
    }

    length = length_ceil(length);

    struct vm_area *vm_ptr = current->vm_area;
    struct vm_area *prev = NULL;
    // if NULL alloc the dummy node
    if(vm_ptr == NULL){
        struct vm_area *new_vma = os_alloc(sizeof(struct vm_area));
        if(new_vma == NULL){
            // printk("os_alloc failed in vmarea dummy\n");
            return -EINVAL;
        }

        current->vm_area = new_vma;
        new_vma->vm_start = MMAP_AREA_START;
        new_vma->access_flags = 0;
        new_vma->vm_end = new_vma->vm_start + __PAGE_SIZE;

        vm_ptr = current->vm_area;

        stats->num_vm_area++;
    }

    u64 addr_map_fixed_success = (u64)NULL;
    u32 flag_merge_prev_possible = 0;
    u32 flag_merge_next_possible = 0;
    long return_value = -EINVAL;

    if((void *)addr != NULL){
        while(vm_ptr != NULL){
            if(prev != NULL && vm_ptr != NULL){
                if(prev->vm_end <= addr && (addr + length) <= vm_ptr->vm_start){
                    addr_map_fixed_success = addr;
                    if(prev->vm_end == addr){
                        flag_merge_prev_possible = 1;
                    }
                    if((addr + length) == vm_ptr->vm_start){
                        flag_merge_next_possible = 1;
                    }
                }
            }

            if(((void *)addr_map_fixed_success) != NULL){
                break;
            }
            prev = vm_ptr;
            vm_ptr = vm_ptr->vm_next;
        }

        if(vm_ptr == NULL && prev != NULL && (((void *)addr_map_fixed_success) == NULL)){
            if(prev->vm_end <= addr){
                addr_map_fixed_success = addr;
                if(prev->vm_end == addr){
                    flag_merge_prev_possible = 1;
                }
            }
        }
    }

    if(flags == MAP_FIXED && ((void *)addr_map_fixed_success == NULL)){
        // printk("map fixed failed to find free region at request\n");
        return -EINVAL;
    }

    u64 final_start_addr;
    if(((void *)addr_map_fixed_success) != NULL){
        return_value = addr_map_fixed_success;
        final_start_addr = addr_map_fixed_success;
    }
    else{
        // search from beginning
        vm_ptr = current->vm_area;
        prev = NULL;
        u64 addr_lowest_available = (u64)NULL;

        while(vm_ptr != NULL){
            if(prev != NULL && vm_ptr != NULL){
                if(prev->vm_end + length <= vm_ptr->vm_start){
                    addr_lowest_available = prev->vm_end;

                    flag_merge_prev_possible = 1;
                    if((prev->vm_end + length) == vm_ptr->vm_start){
                        flag_merge_next_possible = 1;
                    }
                }
            }

            if(((void *)addr_lowest_available) != NULL){
                break;
            }
            prev = vm_ptr;
            vm_ptr = vm_ptr->vm_next;
        }

        if(vm_ptr == NULL && prev != NULL && (((void *)addr_lowest_available) == NULL)){
            if(prev->vm_end + length <= MMAP_AREA_END){
                addr_lowest_available = prev->vm_end;
                flag_merge_prev_possible = 1;
            }
            else{
                // no mem
                // printk("reached end of mem range\n");
                return -EINVAL;
            }
        }

        final_start_addr = addr_lowest_available;
        return_value = addr_lowest_available;
    }

    if(flag_merge_next_possible && flag_merge_prev_possible){
        if(prev->access_flags == vm_ptr->access_flags){
            if(prev->access_flags == prot){
                prev->vm_end = vm_ptr->vm_end;
                prev->vm_next = vm_ptr->vm_next;
                os_free(vm_ptr, sizeof(struct vm_area));

                stats->num_vm_area--;
            }
            else{
                struct vm_area *new_vma = os_alloc(sizeof(struct vm_area));
                if(new_vma == NULL){
                    // printk("os_alloc failed in vmarea\n");
                    return -EINVAL;
                }
                new_vma->access_flags = prot;
                new_vma->vm_start = final_start_addr;
                new_vma->vm_end = final_start_addr + length;

                insert_after(prev, new_vma, vm_ptr);

                stats->num_vm_area++;
            }
        }
        else{
            if(prev->access_flags == prot){
                prev->vm_end = final_start_addr + length;
            }
            else if(vm_ptr->access_flags == prot){
                vm_ptr->vm_start = final_start_addr;
            }
            else{
                struct vm_area *new_vma = os_alloc(sizeof(struct vm_area));
                if(new_vma == NULL){
                    // printk("os_alloc failed in vmarea\n");
                    return -EINVAL;
                }
                new_vma->access_flags = prot;
                new_vma->vm_start = final_start_addr;
                new_vma->vm_end = final_start_addr + length;

                insert_after(prev, new_vma, vm_ptr);

                stats->num_vm_area++;
            }
        }
    }
    else if(flag_merge_prev_possible){
        if(prev->access_flags == prot){
            prev->vm_end = final_start_addr + length;
        }
        else{
            struct vm_area *new_vma = os_alloc(sizeof(struct vm_area));
            if(new_vma == NULL){
                // printk("os_alloc failed in vmarea\n");
                return -EINVAL;
            }
            new_vma->access_flags = prot;
            new_vma->vm_start = final_start_addr;
            new_vma->vm_end = final_start_addr + length;

            insert_after(prev, new_vma, vm_ptr);

            stats->num_vm_area++;
        }
    }
    else if(flag_merge_next_possible){
        if(vm_ptr->access_flags == prot){
            vm_ptr->vm_start = final_start_addr;
        }
        else{
            struct vm_area *new_vma = os_alloc(sizeof(struct vm_area));
            if(new_vma == NULL){
                // printk("os_alloc failed in vmarea\n");
                return -EINVAL;
            }
            new_vma->access_flags = prot;
            new_vma->vm_start = final_start_addr;
            new_vma->vm_end = final_start_addr + length;

            insert_after(prev, new_vma, vm_ptr);

            stats->num_vm_area++;
        }
    }
    else{
        struct vm_area *new_vma = os_alloc(sizeof(struct vm_area));
        if(new_vma == NULL){
            // printk("os_alloc failed in vmarea\n");
            return -EINVAL;
        }
        new_vma->access_flags = prot;
        new_vma->vm_start = final_start_addr;
        new_vma->vm_end = final_start_addr + length;

        insert_after(prev, new_vma, vm_ptr);

        stats->num_vm_area++;
    }

    return return_value;
}

/**
 * munmap system call implemenations
 */

long vm_area_unmap(struct exec_context *current, u64 addr, int length)
{
    if(current == NULL){
        return -EINVAL;
    }
    if(addr < MMAP_AREA_START && addr > MMAP_AREA_END){
        return -EINVAL;
    }
    if(length < 0 || addr + length > MMAP_AREA_END){
        return -EINVAL;
    }

    length = length_ceil(length);
    u64 end_addr = addr + length;

    struct vm_area *prev = NULL;
    struct vm_area *curr_vma = current->vm_area;

    while(curr_vma != NULL){
        u32 mark_delete_node = 0;
        // struct vm_area *next = curr_vma->vm_next;

        if(curr_vma->vm_start == MMAP_AREA_START){
            prev = curr_vma;
            curr_vma = curr_vma->vm_next;
        }
        else if(curr_vma->vm_start >= addr && curr_vma->vm_end < end_addr){
            mark_delete_node = 1;

            prev->vm_next = curr_vma->vm_next;
            // ###################################### part-2 ##############################################################

            for(u64 free_ptr = curr_vma->vm_start; free_ptr < curr_vma->vm_end; free_ptr += __PAGE_SIZE){
                free_physical_allocation(free_ptr, current);
            }

            // ############################################################################################################
            os_free(curr_vma, sizeof(struct vm_area));
            stats->num_vm_area--;
            curr_vma = prev->vm_next;
        }
        else if(curr_vma->vm_start >= addr && curr_vma->vm_end >= end_addr && curr_vma->vm_start < end_addr){
            if(curr_vma->vm_end == end_addr){
                mark_delete_node = 1;

                prev->vm_next = curr_vma->vm_next;
                // ###################################### part-2 ##############################################################

                for(u64 free_ptr = curr_vma->vm_start; free_ptr < curr_vma->vm_end; free_ptr += __PAGE_SIZE){
                    free_physical_allocation(free_ptr, current);
                }

                // ############################################################################################################
                os_free(curr_vma, sizeof(struct vm_area));
                stats->num_vm_area--;
                curr_vma = prev->vm_next;
            }
            else{
                // ###################################### part-2 ##############################################################

                for(u64 free_ptr = curr_vma->vm_start; free_ptr < end_addr; free_ptr += __PAGE_SIZE){
                    free_physical_allocation(free_ptr, current);
                }

                // ############################################################################################################
                curr_vma->vm_start = end_addr;

                prev = curr_vma;
                curr_vma = curr_vma->vm_next;
            }
        }
        else if(curr_vma->vm_start < addr && curr_vma->vm_end < end_addr && addr < curr_vma->vm_end){
            // ###################################### part-2 ##############################################################

            for(u64 free_ptr = addr; free_ptr < curr_vma->vm_end; free_ptr += __PAGE_SIZE){
                free_physical_allocation(free_ptr, current);
            }

            // ############################################################################################################
            curr_vma->vm_end = addr;

            prev = curr_vma;
            curr_vma = curr_vma->vm_next;
        }
        else if(curr_vma->vm_start < addr && curr_vma->vm_end >= end_addr){
            // curr_vma->vm_start < addr && curr_vma->vm_end >= end_addr
            if(curr_vma->vm_end == end_addr){
                // ###################################### part-2 ##############################################################

                for(u64 free_ptr = addr; free_ptr < curr_vma->vm_end; free_ptr += __PAGE_SIZE){
                    free_physical_allocation(free_ptr, current);
                }

                // ############################################################################################################
                curr_vma->vm_end = addr;

                prev = curr_vma;
                curr_vma = curr_vma->vm_next;
            }
            else{
                // ###################################### part-2 ##############################################################

                for(u64 free_ptr = addr; free_ptr < end_addr; free_ptr += __PAGE_SIZE){
                    free_physical_allocation(free_ptr, current);
                }

                // ############################################################################################################
                struct vm_area *new_vma = os_alloc(sizeof(struct vm_area));
                if(new_vma == NULL){
                    // printk("os_alloc failed in vmarea\n");
                    return -EINVAL;
                }
                new_vma->access_flags = curr_vma->access_flags;
                new_vma->vm_start = end_addr;
                new_vma->vm_end = curr_vma->vm_end;
                curr_vma->vm_end = addr;

                new_vma->vm_next = curr_vma->vm_next;
                curr_vma->vm_next = new_vma;

                stats->num_vm_area++;

                prev = new_vma;
                curr_vma = new_vma->vm_next;
            }
        }
        else{
            prev = curr_vma;
            curr_vma = curr_vma->vm_next;
        }
    }

    return 0;
}



/**
 * Function will invoked whenever there is page fault for an address in the vm area region
 * created using mmap
 */

long vm_area_pagefault(struct exec_context *current, u64 addr, int error_code)
{
    // printk("invoked @%x with err code %x\n", addr, error_code);
    if(current == NULL){
        return -EINVAL;
    }

    struct vm_area *vma = current->vm_area;
    while(vma != NULL){
        if(vma->vm_start <= addr && vma->vm_end > addr){
            break;
        }
        vma = vma->vm_next;
    }

    if(vma == NULL){
        // not found - unmapped addr
        return -EINVAL;
    }

    if(error_code == 0x4){
        return do_page_table_walk(addr, current, vma);
    }
    else if(error_code == 0x6){
        if((vma->access_flags & PROT_WRITE) == 0){
            // no write perm
            return -EINVAL;
        }
        else{
            return do_page_table_walk(addr, current, vma);
        }
    }
    else if(error_code == 0x7){
        if((vma->access_flags & PROT_WRITE) == 0){
            // no write perm
            return -EINVAL;
        }
        else{
            return handle_cow_fault(current, addr, vma->access_flags);
        }
    }
    else return -EINVAL;
    return -1;
}

/**
 * cfork system call implemenations
 * The parent returns the pid of child process. The return path of
 * the child process is handled separately through the calls at the 
 * end of this function (e.g., setup_child_context etc.)
 */

long do_cfork(){
    u32 pid;
    struct exec_context *new_ctx = get_new_ctx();
    struct exec_context *ctx = get_current_ctx();
     /* Do not modify above lines
     * 
     * */   
     /*--------------------- Your code [start]---------------*/
    
    pid = new_ctx->pid;
    new_ctx->ppid = ctx->pid;
    new_ctx->type = ctx->type;
    new_ctx->state = ctx->state;
    new_ctx->used_mem = ctx->used_mem;
    u64 ptable_base_pfn = os_pfn_alloc(OS_PT_REG);
    // printk("alloced ptbase %x\n", ptable_base_pfn);
    char *new_pfn_vaddr = osmap(ptable_base_pfn);
    for(int offset = 0; offset < __PAGE_SIZE; offset++){
        *(new_pfn_vaddr + offset) = 0;
    }

    new_ctx->pgd = ptable_base_pfn;
    for(int i = 0; i<MAX_MM_SEGS; i++){
        new_ctx->mms[i] = ctx->mms[i];
    }
    for(int i = 0; i<CNAME_MAX; i++){
        new_ctx->name[i] = ctx->name[i];
    }
    new_ctx->regs = ctx->regs;

    new_ctx->pending_signal_bitmap = ctx->pending_signal_bitmap;
    for(int i = 0; i<MAX_SIGNALS; i++){
        new_ctx->sighandlers[i] = ctx->sighandlers[i];
    }
    new_ctx->ticks_to_sleep = ctx->ticks_to_sleep;
    new_ctx->alarm_config_time = ctx->alarm_config_time;
    new_ctx->ticks_to_alarm = ctx->ticks_to_alarm;

    for(int i = 0; i<MAX_OPEN_FILES; i++){
        new_ctx->files[i] = ctx->files[i];
        // if(ctx->files[i]){
        //     ctx->files[i]->ref_count++;
        // }
    }

    new_ctx->ctx_threads = ctx->ctx_threads;

    // handle mms:
    for(int i = 0; i<MAX_MM_SEGS; i++){
        if(i != MM_SEG_STACK){
            for(u64 addr = new_ctx->mms[i].start; addr < new_ctx->mms[i].next_free; addr += __PAGE_SIZE){
                long ret_val = handle_cow_mem_reassignment(addr, new_ctx, ctx, new_ctx->mms[i].access_flags);
                if(ret_val < 0) return -EINVAL;
            }
        }
        else{
            for(u64 addr = new_ctx->mms[i].start; addr < new_ctx->mms[i].end; addr += __PAGE_SIZE){
                long ret_val = handle_cow_mem_reassignment(addr, new_ctx, ctx, new_ctx->mms[i].access_flags);
                if(ret_val < 0) return -EINVAL;
            }
        }
    }
    
    // handle vmarea
    struct vm_area *vm_ptr = ctx->vm_area;
    struct vm_area *new_vma_prev = NULL;
    // printk("in cfork before allocing vmas: num_vm_areas: %d\n", stats->num_vm_area);

    while(vm_ptr != NULL){
        // alloc new vma for child;
        struct vm_area *vma = os_alloc(sizeof(struct vm_area));
        if(vma == NULL){
            return -EINVAL;
        }

        vma->access_flags = vm_ptr->access_flags;
        vma->vm_start = vm_ptr->vm_start;
        vma->vm_end = vm_ptr->vm_end;
        vma->vm_next = NULL;

        if(new_vma_prev == NULL){
            new_ctx->vm_area = vma;
            new_vma_prev = vma;
        }
        else{
            new_vma_prev->vm_next = vma;
            new_vma_prev = vma;
        }

        // mark readonly pages
        for(u64 addr = vm_ptr->vm_start; addr < vm_ptr->vm_end; addr += __PAGE_SIZE){
            long ret_val = handle_cow_mem_reassignment(addr, new_ctx, ctx, vm_ptr->access_flags);
            if(ret_val < 0) return -EINVAL;
        }

        vm_ptr = vm_ptr->vm_next;
        // stats->num_vm_area++;
    }

    // printk("in cfork after allocing vmas: num_vm_areas: %d\n", stats->num_vm_area);

    // printk("did my cfork stuff\n");
     /*--------------------- Your code [end] ----------------*/
    
     /*
     * The remaining part must not be changed
     */
    copy_os_pts(ctx->pgd, new_ctx->pgd);
    do_file_fork(new_ctx);
    setup_child_context(new_ctx);
    return pid;
}



/* Cow fault handling, for the entire user address space
 * For address belonging to memory segments (i.e., stack, data) 
 * it is called when there is a CoW violation in these areas. 
 *
 * For vm areas, your fault handler 'vm_area_pagefault'
 * should invoke this function
 * */

long handle_cow_fault(struct exec_context *current, u64 vaddr, int access_flags)
{
    // asm volatile("movq %%cr3, %%rax;" 
    //   "movq %%rax, %%cr3;"
    //  :         /* output */
    //  :         /* input */
    //  :"%rax"         /* clobbered register */
    // );

    // printk("cow fault %x @ pid : %d\n", vaddr, current->pid);
    
    // printk("%x\n", vaddr);
    u64 cr3_contents = current->pgd;
    // printk("cr3: %x\n", cr3_contents);
    // u64 cr3_pfn_number = cr3_contents>>12;
    u64 cr3_pfn_number = cr3_contents;

    void *virtual_pt_lvl_0 = osmap(cr3_pfn_number);
    // printk("vaddr of pt base: %x\n", virtual_pt_lvl_0);

    u64 lvl_0_offset = ((vaddr>>39) & 511);
    u64 lvl_1_offset = ((vaddr>>30) & 511);
    u64 lvl_2_offset = ((vaddr>>21) & 511);
    u64 lvl_3_offset = ((vaddr>>12) & 511);

    u64 lvl_0_contents = *(((u64 *) virtual_pt_lvl_0) + lvl_0_offset);
    // printk("lvl0 contents : %x\n", lvl_0_contents);

    if((lvl_0_contents & 1ULL) == 0){
        // printk("first level not allocated\n");
        return -EINVAL;
    }

    u64 lvl_1_pfn = lvl_0_contents>>12;
    // printk("%x\n", lvl_1_pfn);
    void *virtual_pt_lvl_1 = osmap(lvl_1_pfn);
    u64 lvl_1_contents = *(((u64 *) virtual_pt_lvl_1) + lvl_1_offset);

    if((lvl_1_contents & 1ULL) == 0){
        // printk("second level not allocated\n");
        return -EINVAL;
    }

    u64 lvl_2_pfn = lvl_1_contents>>12;
    void *virtual_pt_lvl_2 = osmap(lvl_2_pfn);
    u64 lvl_2_contents = *(((u64 *) virtual_pt_lvl_2) + lvl_2_offset);

    if((lvl_2_contents & 1ULL) == 0){
        // printk("third level not allocated\n");
        return -EINVAL;
    }

    u64 lvl_3_pfn = lvl_2_contents>>12;
    void *virtual_pt_lvl_3 = osmap(lvl_3_pfn);
    u64 lvl_3_contents = *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset);

    if((lvl_3_contents & 1ULL) == 1){
        // printk("actual level not allocated\n");
        u64 pfn_number = os_pfn_alloc(USER_REG);
        u64 perms;
        if(access_flags & PROT_WRITE){
            perms = 0x19;
        }
        else {
            invlpg_my(vaddr);
            return 1;
        }
        // else return -EINVAL;

        u64 old_pfn_number = *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset);
        // printk("old pte entry %x\n", old_pfn_number);
        old_pfn_number = old_pfn_number>>12;

        *(((u64 *) virtual_pt_lvl_3) + lvl_3_offset) = ((pfn_number<<12) | perms);
        invlpg_my((u64)(((u64 *) virtual_pt_lvl_3) + lvl_3_offset));

        void *old_mem = osmap(old_pfn_number);
        void *new_mem = osmap(pfn_number);
        // printk("%x-old pfn %x-new pfn %x-old mem %x-new mem\n", old_pfn_number, pfn_number ,old_mem, new_mem);
        memcpy(new_mem, old_mem, __PAGE_SIZE);

        // printk("putting %x at pid : %d in cow vadrr %x\n",old_pfn_number, current->pid, vaddr);
        // printk("refcount before put : %d in cow\n", get_pfn_refcount(old_pfn_number));
        put_pfn(old_pfn_number);
        // printk("refcount after put : %d in cow\n", get_pfn_refcount(old_pfn_number));

        if(get_pfn_refcount((old_pfn_number)) == 0){
            // printk("freed old pfn vaddr %x\n", vaddr);
            os_pfn_free(USER_REG, (old_pfn_number));
        }

        invlpg_my(vaddr);
        // printk("\n");
        return 1;
    }

    // printk("returned -1\n");
    // return 1;
    return -EINVAL;
}
